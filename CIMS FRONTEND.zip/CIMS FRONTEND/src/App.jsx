import React from 'react';
import './App.css';
import { Routes, Route, Navigate } from 'react-router-dom';


// General Pages
import Home from './Pages/Home/Home';
import Aboutus from './Pages/Aboutus/Aboutus';
import Policies from './Pages/Policies/Policies';
import Contactus from './Pages/Contactus/Contactus';
import AuthenticationPage from './Pages/Components/Auth/AuthenticationPage';


// Parent Components
import ParentRegistration from './Pages/Components/Parent/ParentRegistration';
import ParentDashboard from './Pages/Components/Parent/ParentDashboard';
import ParentEmailEdit from './Pages/Components/Parent/ParentEmailEdit';
import Allcontact from './Pages/Components/Parent/Allcontact';

// Admin Components
import AdminDashboard from './Pages/Components/Admin/AdminDashboard';

// Payment/Policy Pages
import Gateway from './Pages/Payment/Gateway';
import Payment from './Pages/Payment/Payment';
import PolicyForm from './Pages/Components/Parent/Policyform';
import Claim from './Pages/Components/Claim/Claim';
import Getpolicy from './Pages/Components/Parent/Getpolicy';



function App() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Home />} />
      <Route path="/Policies" element={<Policies />} />
      <Route path="/Aboutus" element={<Aboutus />} />
      <Route path="/Contactus" element={<Contactus />} />

      {/* Authentication Routes */}
      <Route path="/login" element={<AuthenticationPage />} />
      <Route path="/register" element={<ParentRegistration />} />

      {/* Protected Parent Routes */}
      <Route path="/parent-dashboard" element={<ParentDashboard />} />
      <Route path="/edit-parent-email" element={<ParentEmailEdit />} />
      <Route path="/Allcontact" element={<Allcontact />} />

      {/* Protected Admin Routes */}
      <Route path="/admin-dashboard" element={<AdminDashboard />} />

      {/* Policy/Payment Routes */}
      <Route path="/Buypolicy" element={<Gateway />} />
      <Route path="/payment/:productId" element={<Payment />} />
      <Route path='/policy-form' element={<PolicyForm />} />
    
      <Route path='/Claim-form' element={<Claim />} />
      <Route path='/Detail-policy' element={<Getpolicy />} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;

