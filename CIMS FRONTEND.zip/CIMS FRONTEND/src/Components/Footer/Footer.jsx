import React from "react";
import "./Footer.css";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-brand">
          <h2 className="footer-title">
          C - Insurance
          </h2>
          <p className="footer-description">
          Child Insurance provides financial security for your child's future by covering unexpected medical costs and offering investment benefits. It ensures funds for education, health emergencies, and life goals, giving parents peace of mind and children a protected future
          </p>
        </div>

        <div className="footer-section">
          <div>
            {" "}
            <h3 className="footer-heading">Quick Links</h3>
          </div>
          <div className="foot2">
            <Link to="/">Home</Link>
            <Link to="/Policies">Policies</Link>
            <Link to="/Aboutus">About-Us</Link>
            <Link to="/Contactus">Contact-Us</Link>
            {/* <Link to="/admin-dashboard">Admin</Link> */}
            <Link to="/login">Login</Link> 
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
