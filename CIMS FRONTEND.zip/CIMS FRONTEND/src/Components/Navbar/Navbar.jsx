import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaTimes, FaBars } from 'react-icons/fa';
import './Navbar.css'; 

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    
    <div className="navbar">
      <div className="logo">
        <h1>
        C - Insurance &#x2655;
        </h1>
      </div>

      <div className={`nav-links ${menuOpen ? 'active' : ''}`}>
        <Link to="/">Home</Link>
        <Link to="/Policies">Policies</Link>
        <Link to="/Aboutus">About-Us</Link>
        <Link to="/Contactus">Contact-Us</Link>
        {/* <Link to="/admin-dashboard">Admin</Link> */}
         <Link to="/login">Login</Link> 
      </div>

      <div className="menu-icon" onClick={toggleMenu}>
        {menuOpen ? (
          <FaTimes size={25} style={{ color: 'black' }} />
        ) : (
          <FaBars size={25} style={{ color: 'black' }} />
        )}
      </div>
    </div>
  
  );
};

export default Navbar;
