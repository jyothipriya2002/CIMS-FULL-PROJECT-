import React from 'react'
import Navbar from '../../Components/Navbar/Navbar'
import Footer from '../../Components/Footer/Footer'
import Aboutpg1 from './Components/Aboutpg1'
import Aboutpg2 from './Components/Aboutpg2'
import Aboutpg3 from './Components/Aboutpg3'
import Aboutpg4 from './Components/Aboutpg4'
import Aboutpg5 from './Components/Aboutpg5'
import Aboutpg6 from './Components/Aboutpg6'


const Aboutus = () => {
  return (
    <div>
      <Navbar />
      <Aboutpg1 />
      <Aboutpg2 />
      <Aboutpg3 />
      <Aboutpg4 />
      <Aboutpg5 />
      <Aboutpg6 />
      <Footer />
    </div>
  )
}

export default Aboutus
