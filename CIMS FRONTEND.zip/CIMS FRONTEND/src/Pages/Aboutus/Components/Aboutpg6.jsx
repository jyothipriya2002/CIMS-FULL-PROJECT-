import React from "react";
import "./About.css";
import Happyimg from "../../../assets/Happyimg1.jpeg";

const Aboutpg6 = () => {
  return (
    <div className="aboutpg6-container">
      <div className="aboutpg6-wrapper">
        <div className="aboutpg6-text">
          <h2 className="aboutpg6-heading">
            We support{" "}
            <span className="highlight">visionary entrepreneurs</span>.
          </h2>
          <p className="aboutpg6-para">
            C - Insurance &#x2655;, our corporate capital
            investment division, helps deliver value to our customers and
            agents. We're using our expertise, reach and history of success to
            bring innovative products and solutions to market.
          </p>
        </div>
        <img
          src={Happyimg}
          alt="Entrepreneur Building"
          className="aboutpg6-image"
        />
      </div>
    </div>
  );
};

export default Aboutpg6;
