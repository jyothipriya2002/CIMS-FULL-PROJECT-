import React from 'react'
import './About.css';

const Aboutpg1 = () => {
  return (
    <div className='aboutpg1-container'>
      <div className="aboutpg1-left">
        <h1>
          About us
        </h1>
        <p>
        Striving to provide as near perfect protection as humanly possible, since 1925.
        </p>
      </div>
    </div>
  )
}

export default Aboutpg1
