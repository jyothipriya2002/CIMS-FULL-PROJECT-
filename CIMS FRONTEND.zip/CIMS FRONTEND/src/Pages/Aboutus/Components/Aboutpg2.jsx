// import React from "react";
// import "./About.css";

// const Aboutpg2 = () => {
//   return (
//     <div className="aboutpagecontainer">
//       <div className="aboutpg_div">
//         <h1>About Us</h1>
//         <p>
//           Welcome to Child Insurance Management System, a reliable and
//           user-friendly platform designed to simplify the process of managing
//           insurance plans for children. Our mission is to provide parents and
//           guardians with a secure and efficient way to track, update, and
//           maintain insurance policies tailored for their child’s future needs.
//           It simplifies the tracking and management of child insurance plans by
//           digitizing key tasks such as policy registration, premium tracking,
//           and report generation. The system offers features like automated
//           alerts for upcoming payments, secure data handling, and easy access to
//           policy details, ensuring transparency and convenience for users. With
//           this platform, users can save time, reduce paperwork, and make
//           informed decisions regarding their child’s financial protection. It is
//           especially useful for families, insurance agents, schools in
//           partnership with insurers, and organizations focused on child
//           welfare.In addition to managing policy details, the system provides
//           secure storage of personal and financial information, safeguarding it
//           against unauthorized access. It can also generate detailed reports
//           summarizing payment history, policy status, and future benefits, which
//           helps users plan better for their child’s future needs such as
//           education or healthcare. One of the standout features is its
//           accessibility—users can log in from anywhere to view or update policy
//           information, eliminating the need for in-person visits to insurance
//           offices. The system can also be customized to cater to specific types
//           of policies like health insurance for special needs children,
//           educational savings plans, or long-term investment-based child
//           policies. Overall, the Child Insurance Management System promotes
//           responsible financial planning and enhances trust in the management of
//           child welfare policies.
//         </p>
//       </div>
//     </div>
//   );
// };

// export default Aboutpg2;
import React from "react";
import "./About.css";

const Aboutpg2 = () => (
  <section className="aboutpg2-container">
    <div className="aboutpg2-content">
      <h1 className="aboutpg2-heading">
        <strong>Get peace of mind</strong>{" "}
        <span>with C - Insurance &#x2655;</span>
      </h1>
      <p className="aboutpg2-text">
        For nearly a century, C - Insurance &#x2655; Group has
        rooted itself in the principles of honesty, decency, service, and
        affordability. Prioritizing customer service first has helped us become
        one of the largest insurers for child insurance. We're now a Fortune 500
        company with more than 6 million active policies, and we're still
        putting you – our customers – first.
      </p>
      <button className="aboutpg2-button">Explore our history →</button>
    </div>
  </section>
);

export default Aboutpg2;
