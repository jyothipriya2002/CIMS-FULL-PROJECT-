import React from 'react';
import './About.css';

const Aboutpg4 = () => {
  return (
    <div className="aboutpg4-container">
      <div className="aboutpg4-content">
        <h2 className="aboutpg4-heading">
          We're <span className="highlight">part of the community</span>.
        </h2>
        <p className="aboutpg4-text">
          Our 7,000+ employees and 14,000 agents live and work in hometowns like yours.
          We give back in different ways – from delivering Meals on Wheels and coaching Little League,
          to helping rebuild after a catastrophe – and we're proud to help our customers when they need us the most.
        </p>
      </div>
    </div>
  );
};

export default Aboutpg4;
