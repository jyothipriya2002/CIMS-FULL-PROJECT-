import React from 'react';
import './About.css';
import Founder1 from "../../../assets/Founder1.jpg";

const Aboutpg5 = () => {
  return (
    <div className="aboutpg5-container">
      <div className="aboutpg5-wrapper">
        <img src={Founder1} alt="Founder" className="aboutpg5-image" />
        <div className="aboutpg5-text">
          <h2 className="aboutpg5-heading">
            We celebrate <span className="highlight">diversity, equity, and inclusion</span>.
          </h2>
          <p className="aboutpg5-para">
            Since our founding, our leaders have worked to treat others as they treat themselves.
            That guiding principle continues to influence us today.
            We know that by committing to this work, we will develop a greater understanding of our communities
            and address the business challenges and opportunities that lie ahead.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Aboutpg5;
