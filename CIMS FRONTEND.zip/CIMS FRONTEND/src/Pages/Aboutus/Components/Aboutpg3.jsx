// import React from 'react';
// import './About.css';

// const Aboutpg3 = () => {
//   return (
//     <div className="about-stats-container">
//       <h2 className="stats-heading">
//         Here are some of the numbers that speak about our accomplishments.
//       </h2>
//       <div className="stats-grid">
//         <div className="stat-card">
//           <h3>99.65%<sup>^</sup> Death Claim Paid Ratio</h3>
//           <p>(Source: Individual Death Claim Paid Ratio as per audited financials for FY 2023-24)</p>
//         </div>
//         <div className="stat-card">
//           <h3>304 Offices</h3>
//           <p>(Source: As reported to IRDAI, FY 2023-24)</p>
//         </div>
//         <div className="stat-card">
//           <h3>₹1,779,409 Cr. Sum Assured</h3>
//           <p>In force (individual) (Source: Axis Max Life Public Disclosure, FY 2023-24)</p>
//         </div>
//         <div className="stat-card">
//           <h3>₹150,836 Cr. Assets Under Management</h3>
//           <p>(Source: Axis Max Life Public Disclosure, FY 2023-24)</p>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Aboutpg3;
import React from 'react';
import './About.css';

const Aboutpg3 = () => (
  <section className="aboutpg3-container">
    <div className="aboutpg3-content">
      <div className="aboutpg3-quote-mark">"</div>
      <div className="aboutpg3-quote-text">Never lose the human touch.</div>
      <div className="aboutpg3-divider" />
      <div className="aboutpg3-author">
        <strong>Bhanu Mammayya</strong>
        <div>Founder</div>
      </div>
    </div>
  </section>
);

export default Aboutpg3;


