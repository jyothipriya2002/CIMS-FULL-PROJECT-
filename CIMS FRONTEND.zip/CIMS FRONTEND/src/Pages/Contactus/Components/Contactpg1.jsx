import React from 'react';
import './Contact.css';
import { Link } from 'react-router-dom';

const Contactpg1 = () => {
  return (
    <div className="contactpg1-container">
      <div className="contactpg1-hero">
        <h1 className="contactpg1-title">Contact <span>us</span></h1>
        <p className="contactpg1-subtitle">
          Not sure where to get started? We've got you covered.
        </p>
      </div>

      <div className="contactpg1-info">
        <h2 className="contactpg1-heading">
          We're <span>ready to help.</span>
        </h2>
        <p className="contactpg1-paragraph">
          For assistance with all your policy and service needs, contact <Link to={"#"}>your local C - Insurance &#x2655; agent</Link> during normal business hours.
        </p>
      </div>
    </div>
  );
};

export default Contactpg1;
