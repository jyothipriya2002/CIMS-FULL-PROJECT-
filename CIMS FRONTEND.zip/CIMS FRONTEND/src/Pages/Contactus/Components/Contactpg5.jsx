import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Contact.css';

const Contactpg5 = () => {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState(null);

  const handleSelect = (option) => {
    setSelectedOption(option);
  };

  const handleNext = () => {
    if (selectedOption) {
      navigate('/Policies');
    } else {
      alert('Please select an option before proceeding.');
    }
  };

  return (
    <div className="contactpg5-container">
      <h2 className="question">What's your biggest financial goal?</h2>
      <p className="subtext">(Choose one)</p>

      <div className="options-container">
        {['Save for college', 'Save for personal health', 'Save for Multi purpose'].map((option, index) => (
          <div
            key={index}
            className={`option-card ${selectedOption === option ? 'selected' : ''}`}
            onClick={() => handleSelect(option)}
          >
            {option}
          </div>
        ))}
      </div>

      <button
        className={`next-button ${selectedOption ? 'enabled' : ''}`}
        onClick={handleNext}
      >
        Next
      </button>
    </div>
  );
};

export default Contactpg5;
