import React from "react";
// import { FcCallback } from "react-icons/fc";
import { MdEmail, MdSms, MdPhoneCallback } from "react-icons/md";
import "./Contact.css";
import { Link } from "react-router-dom";

const Contactpg2 = () => {
  return (
    <div className="contact-container">
      <div className="contact-header">
        <h1>CONTACT US</h1>
        <h2>Feel Free to reach out to us</h2>
      </div>

      <div className="contact-content">
        <div className="map-section">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31089.25937047556!2d77.63162199786761!3d13.089207834276637!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae198812ff784d%3A0x818d357937b4cb38!2sKannuru%2C%20Bengaluru%2C%20Karnataka!5e0!3m2!1sen!2sin!4v1745949409618!5m2!1sen!2sin"
            width="100%"
            height="350"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Google Map"
          ></iframe>
        </div>

        <div className="contact-info">
          <h2>Contact Info</h2>

          <div className="info-item">
            <MdPhoneCallback className="icon" />
            <span>
              <strong>Call us toll free at:</strong> 1800 267 9090 (Available 24x7)
            </span>
          </div>

          <div className="info-item">
            <MdEmail className="icon" />
            <span>
              <strong>Email us at:</strong> info@e-insure.co.in
            </span>
          </div>

          <div className="info-item">
            <MdSms className="icon" />
            <span>
              <strong>SMS LIBERATE:</strong> 56161 <Link to="#">SMS Services</Link>
            </span>
          </div>

          <button className="callback-btn">Request a Call Back</button>

          <p className="note">
            As per IRDAI circular, dated 2nd June, 2023, bearing reference number IRDA/F&I/ORD/MISC/119/6/2023. 
          </p>
        </div>
      </div>
    </div>
  );
};

export default Contactpg2;
