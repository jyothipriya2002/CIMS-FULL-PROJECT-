import React, { useState } from 'react';
import './Contact.css';

const dummyAgents = [
  { name: 'Ravi Kumar', address: '123 MG Road, Bengaluru, KA', phone: '987543210' },
  { name: 'Anjali Mehta', address: '56 Park Street, Kolkata, WB', phone: '9123456789' },
  { name: 'Amit Sharma', address: '78 Nehru Nagar, Chennai, TN', phone: '9001234567' },
  { name: 'Priya Verma', address: '22 Ring Road, Delhi, DL', phone: '9898989898' }
];

const Contactpg4 = () => {
  const [inputValue, setInputValue] = useState('');
  const [agentInfo, setAgentInfo] = useState(null);

  const handleFindAgency = () => {
    if (inputValue.trim()) {
      const randomAgent = dummyAgents[Math.floor(Math.random() * dummyAgents.length)];
      setAgentInfo(randomAgent);
    }
  };

  const handleClear = () => {
    setInputValue('');
    setAgentInfo(null);
  };

  return (
    <div className="contactpg4-container">
      <h2 className="contactpg4-heading">
        Ready to <span>get started?</span>
      </h2>
      <p className="contactpg4-subtext">Get in touch with a local agent.</p>

      <div className="contactpg4-form">
        <input
          type="text"
          className="contactpg4-input"
          placeholder="Address, City, State, or ZIP"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
        />
        <button className="contactpg4-button" onClick={handleFindAgency}>
          Find an agency →
        </button>
        <button className="contactpg4-button contactpg4-clear" onClick={handleClear}>
          Clear
        </button>
      </div>

      {agentInfo && (
        <div className="contactpg4-result">
          <p><strong>Agent Name:</strong> {agentInfo.name}</p>
          <p><strong>Address:</strong> {agentInfo.address}</p>
          <p><strong>Phone:</strong> {agentInfo.phone}</p>
          <p className="safe-msg">Your data is safe with us.</p>
        </div>
      )}
    </div>
  );
};

export default Contactpg4;
