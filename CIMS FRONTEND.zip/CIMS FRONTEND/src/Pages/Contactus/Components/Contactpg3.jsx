import React from 'react';
import './Contact.css';
import { FiPhoneCall } from 'react-icons/fi';

const Contactpg3 = () => {
  return (
    <div className="helpline-container">
      <div className="helpline-card">
        <h2>Customer Service Helpline :</h2>
        <p>For existing customers</p>
        <div className="helpline-detail">
          <FiPhoneCall className="helpline-icon" />
          <div className="helpline-text">
            <span>1860 120 5577</span>
            <span>(09:00 AM to 6:00 PM, Monday to Saturday)</span>
            <span>Please call from registered mobile number</span>
          </div>
        </div>
      </div>

      <div className="helpline-card">
        <h2>Online Sales Helpline:</h2>
        <p>To know the status/pending requirements of an ongoing application or buy a new plan</p>
        <div className="helpline-detail">
          <FiPhoneCall className="helpline-icon" />
          <div className="helpline-text">
            <span>0124 648 8900</span>
            <span>(09:00 AM to 09:00 PM, Monday to Saturday)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contactpg3;
