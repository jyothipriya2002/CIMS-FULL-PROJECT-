import React from 'react'
import Navbar from '../../Components/Navbar/Navbar';
import Footer from '../../Components/Footer/Footer';
import Contactpg1 from './Components/Contactpg1';
import Contactpg2 from './Components/Contactpg2';
import Contactpg3 from './Components/Contactpg3';
import Contactpg4 from './Components/Contactpg4';
import Contactpg5 from './Components/Contactpg5';

const Contactus = () => {
  return (
    <div>
      <Navbar />
      <Contactpg1 />
      <Contactpg2 />
      <Contactpg3 />
      <Contactpg4 />
      <Contactpg5 />
      <Footer />
    </div>
  )
}

export default Contactus
