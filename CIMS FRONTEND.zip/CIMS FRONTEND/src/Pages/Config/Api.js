// Use relative URLs instead of absolute URLs
const API_BASE = '/api';

const API_ENDPOINTS = {
    // Auth endpoints
    LOGIN: `${API_BASE}/user/login`,
    ADMIN_LOGIN: `${API_BASE}/admin/login`,
    
    // User endpoints
    USER_DETAILS: (email) => `${API_BASE}/user/details/${email}`,
    USER_REGISTRATION: `${API_BASE}/user/registration`,
    UPDATE_EMAIL: `${API_BASE}/update-email`,
};

// Common fetch options for all API calls
export const fetchOptions = {
    credentials: 'include',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
};

export default API_ENDPOINTS; 