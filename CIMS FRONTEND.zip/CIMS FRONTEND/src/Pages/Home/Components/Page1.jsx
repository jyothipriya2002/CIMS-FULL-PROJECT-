import React from "react";
import img1 from "../../../assets/Parents.jpg";
import "./Hero.css";
import { Link } from "react-router-dom";
// import check from "../../../assets/checkmark.jpg";
// import check from "../assets/checkmark.jpg";
import check from "../../../assets/checkmark.png";
import phone from "../../../assets/telephone.png";

const Page1 = () => {
  return (
    <div className="container1">
      <h1>Policies</h1>

      <div className="page1-div">
        <div className="img-div">
          <img src={img1} alt="Happy family coloring at home" />
        </div>
        <div className="content-div">
          <div>
            <h1>
              Insurance for the better <br /> Family Life
            </h1>
          </div>
          <div>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime
              error ducimus quasi quo sit, iste autem nam eius quibusdam
              suscipit commodi nulla! Debitis facere fugit minus eaque
              inventore, officia explicabo!
            </p>
          </div>
          <div className="div1">
            <div className="checkdiv">
              <div className="check-mark-div">
                <img src={check} alt="" />
                <p>Simplify your Process</p>
              </div>
              <div className="check-mark-div">
                <img src={check} alt="" />
                <p>Know what your family needs</p>
              </div>
            </div>

            <div className="checkdiv">
              <div className="check-mark-div">
                <img src={check} alt="" />
                <p>Start now</p>
              </div>
              <div className="check-mark-div">
                <img src={check} alt="" />
                <p>A whole digital love for less</p>
              </div>
            </div>
          </div>

          <div className="policylink-div">
            <div className="policy-page-div">
              <Link to="/Policies">Know More</Link>
            </div>
            <div className="helpdesk-div">
              <div className="phone-img">
                <img src={phone} alt="" />
              </div>
              <div className="helpdesk-content">
                <h3>Help Desk 24/7</h3>
                <h3>(+91) 1800 - 123 - 456</h3>
              </div>
            </div>
          </div>
          <div className="experience">
            <div className="years">
              <h1>30 +</h1>
              <p>Years</p>
            </div>
            <div>
              <p>Of Experience In<br />Providing Child Insurance</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page1;
