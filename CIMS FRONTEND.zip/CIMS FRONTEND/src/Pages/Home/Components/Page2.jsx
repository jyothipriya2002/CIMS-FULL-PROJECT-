import React from "react";
import "./Hero.css";
import family from "../../../assets/family1.png";

const Page2 = () => {
  return (
    <div className="review">
      <div className="client-div">
        <h2>Clients Talk</h2>
        <h2>Experience Financial Growth With Us</h2>
      </div>
      <div className="review-div">
        <div className="review-img">
          <img src={family} alt="happy family" />
        </div>
        <div className="review-content">
          <h1>Here people say about us</h1>
          <p>
            "I'm really impressed with this digital child insurance company.
            The online process was quick, transparent, and hassle-free.
            Managing the policy and tracking progress is super easy. Customer
            service is responsive and helpful at every step. It's a smart and
            secure way to plan for my child's future."
          </p>
          <h3>John Doe</h3>
        </div>
      </div>
    </div>
  );
};

export default Page2;
