import React, { useState } from 'react';
import './Hero.css'; // Make sure to create this CSS file for styling

const Accordion = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const items = [
    { title: 'Why To Choose Us', content: 'Our Company has been loyal to our customer by giving them best services ' },
    { title: 'How to Contact Us', content: 'Navigate through our Contact us page for contacting us' },
    { title: 'Type Of Insurance', content: 'we provide EduHealthShield, Guardian Shield, BrightPath EduShield' },
  ];

  return (
    <div className="accordion">
      {items.map((item, index) => (
        <div key={index} className="accordion-item">
          <div
            className="accordion-header"
            onClick={() => toggleAccordion(index)}
          >
            <h3>{item.title}</h3>
            <span>{activeIndex === index ? '-' : '+'}</span>
          </div>
          {activeIndex === index && (
            <div className="accordion-content">
              <p>{item.content}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default Accordion;
