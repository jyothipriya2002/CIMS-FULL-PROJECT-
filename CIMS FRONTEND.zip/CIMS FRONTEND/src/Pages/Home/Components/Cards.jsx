// import React from "react";
// import insurance1 from "../../../assets/insurance1.jpg";
// import insurance2 from "../../../assets/insurance2.jpg";
// // import insurance3 from "../../../assets/insurance3.jpg";
// import insurance4 from "../../../assets/insurance4.jpg";
// import "./Hero.css";

// const Cards = () => {
//   return (
//     <div className="cards">
//       <div className="card-div">
//         <div className="card1">
//         <img src={insurance1} alt="" />
//         </div>
//         <div className="card1">
//         <h4>Health Insurance</h4>
//         <p>
//           Health insurance is a contract that helps cover medical expenses,
//           including doctor visits, hospital stays, and prescriptions. It offers
//           financial protection .....
//         </p>
//         </div>
//       </div>
//       <div className="card-div">
//         <img src={insurance2} alt="" />
//         <h4>hello</h4>
//       </div>
//       <div className="card-div">
//         <img src={insurance4} alt="" />
//         <h4>hello</h4>
//       </div>
//     </div>
//   );
// };

// export default Cards;

import React from "react";
import { Link } from "react-router-dom";
import insurance1 from "../../../assets/insurance1.jpg";
import insurance2 from "../../../assets/insurance2.jpg";
import insurance4 from "../../../assets/insurance4.jpg";
import "./Hero.css";

const Cards = () => {
  return (
    <div className="cards-container">
      <div className="card">
        <Link to="/Policies">
          <img src={insurance1} alt="Health Insurance" className="card-img" />
        </Link>
        <div className="card-content">
          <h4>Guardian Shield</h4>
          <p>
          Guardian Shield is a contract that helps cover medical expenses,
            including doctor visits, hospital stays, and prescriptions. It
            offers financial protection...
          </p>
        </div>
      </div>

      <div className="card">
        <Link to="/Policies">
          <img src={insurance2} alt="Card 2" className="card-img" />
        </Link>
        <div className="card-content">
          <h4>EduHealth Shield</h4>
          <p>
          EduHealth Shield insurance is a financial plan that helps parents
            save for their child’s future education. It offers investment
            benefits along with insurance...
          </p>
        </div>
      </div>

      <div className="card">
        <Link to="/Policies">
          <img src={insurance4} alt="Card 3" className="card-img" />
        </Link>
        <div className="card-content">
          <h4>BrightPath EduShield</h4>
          <p>
            A BrightPath EduShield is a traditional life insurance policy that
            combines savings and insurance. It provides a lump sum payout on
            maturity...
          </p>
        </div>
      </div>
    </div>
  );
};

export default Cards;
