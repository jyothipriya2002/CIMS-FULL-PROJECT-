import React from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import Openness from '../../../assets/Hero1.jpeg';
import Prudence from '../../../assets/Hero2.jpeg';
import Relationship from '../../../assets/Hero3.jpeg';
import Services from '../../../assets/Hero4.jpeg';
import { FaArrowLeft, FaArrowRight } from 'react-icons/fa';
import './Hero.css';

const PrevArrow = ({ onClick }) => (
  <div className="custom-arrow left" onClick={onClick}>
    <FaArrowLeft />
  </div>
);

const NextArrow = ({ onClick }) => (
  <div className="custom-arrow right" onClick={onClick}>
    <FaArrowRight />
  </div>
);

const Hero = () => {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    fade: true,
    cssEase: "linear",
    slidesToShow: 1,
    slidesToScroll: 1,
    speed: 500,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 1,
          dots: true
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: true
        }
      }
    ]
  };

  return (
    <section className='slider-container'>
      <Slider {...settings}>
        <div>
          <img src={Openness} alt="Openness" className="slider-image" />
        </div>
        <div>
          <img src={Prudence} alt="Prudence" className="slider-image" />
        </div>
        <div>
          <img src={Relationship} alt="Relationship" className="slider-image" />
        </div>
        <div>
          <img src={Services} alt="Services" className="slider-image" />
        </div>
      </Slider>
    </section>
  );
};

export default Hero;
