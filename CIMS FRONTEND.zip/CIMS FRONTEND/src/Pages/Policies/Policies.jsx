import React from 'react'
import Navbar from '../../Components/Navbar/Navbar';
 import Footer from '../../Components/Footer/Footer';
import Calculator from './Components/Calculator';
import Content1 from './Components/Content1';
import Policiespage2 from './Components/Policiespage2';
import EduHealthShield from './Components/EduHealthShield';
import BrightPathEduShield from './Components/BrightPathEduShield';


const Policies = () => {
  return (
    <div>
      <Navbar />
      <Calculator />
      <Content1 />
      <Policiespage2 />
      <EduHealthShield />
      <BrightPathEduShield />
      <Footer />
    </div>
  )
}

export default Policies
