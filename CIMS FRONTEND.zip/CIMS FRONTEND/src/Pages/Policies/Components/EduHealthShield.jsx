import React from "react";
import insurance2 from "../../../assets/insurance2.jpg";
import ChildEducationCalculator from './ChildEducationCalculator';
import './Policies.css';
import { Link } from 'react-router-dom';

const EduHealthShield = () => {
  return (
    <div className="policies-container">
      <div className="content-wrapper">
        <div className="policy-info">
          <h1>EduHealth Shield</h1>
          <p>
            EduHealth Shield insurance is a financial plan that helps parents
            save for their child’s future education. It offers investment
            benefits along with insurance.
          </p>
          <Link to="/login">Apply Now &#x27F6;</Link><br />
          <a href="/EduHealth%20Shield.pdf" target="_blank" rel="noopener noreferrer">
            View EduHealth Shield Brochure &#x27F6;
          </a>
          <img src={insurance2} alt="" />
        </div>
        <div>
        <section className="calculator-wrapper">
          <ChildEducationCalculator />
        </section>
        </div>
      </div>
    </div>
  );
};

export default EduHealthShield;
