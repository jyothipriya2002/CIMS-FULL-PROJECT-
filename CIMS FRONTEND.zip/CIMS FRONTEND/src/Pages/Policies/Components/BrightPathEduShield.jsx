import React from "react";
import insurance4 from "../../../assets/insurance4.jpg";
import ChildEduSavCalculator from "./ChildEduSavCalculator";
import "./Policies.css";
import { Link } from "react-router-dom";

const BrightPathEduShield = () => {
  return (
    <div className="policies-container">
      <div className="content-wrapper">
        <div className="policy-info">
          <h1>BrightPathEdu Shield</h1>
          <p>
            A BrightPath EduShield is a traditional life insurance policy that
            combines savings and insurance. It provides a lump sum payout on
            maturity.​BrightPathEdu Shield is an innovative insurance solution
            that combines educational and health coverage into a single,
            comprehensive plan. This dual-purpose approach is designed to
            support families—particularly those with children or young adults—by
            addressing both academic and healthcare needs in a unified package.
          </p>
          <Link to="/login">Apply Now &#x27F6;</Link>
          <br />
          <a
            href="/BrightPathEduHealthShield.pdf"
            target="_blank"
            rel="noopener noreferrer"
          >
            View BrightPath EduHealth Shield Brochure &#x27F6;
          </a>

          <img src={insurance4} alt="" />
        </div>
        <div>
          <section className="calculator-wrapper">
            <ChildEduSavCalculator />
          </section>
        </div>
      </div>
    </div>
  );
};

export default BrightPathEduShield;
