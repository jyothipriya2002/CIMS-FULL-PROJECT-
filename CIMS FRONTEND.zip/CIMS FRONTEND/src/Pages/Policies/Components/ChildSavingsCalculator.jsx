import React, { useState } from 'react';
import './Policies.css';

const ChildSavingsCalculator = () => {
  const [formData, setFormData] = useState({
    childName: '',
    childDob: '',
    gender: '',
    dob: '',
    income: '',
    mobile: '',
    email: '',
    qualification: '',
    occupation: '',
    pincode: '',
    city: '',
    consent: false,
    monthlyInvestment: 6000,
    annualReturnRate: 0.07
  });

  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({ ...formData, [name]: type === 'checkbox' ? checked : value });
  };

  const calculateReturns = () => {
    const dob = new Date(formData.childDob);
    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
    const remainingYears = 18 - age;

    if (remainingYears <= 0) {
      setResult('Child is already 18 or older.');
      return;
    }

    const months = remainingYears * 12;
    const monthlyRate = Math.pow(1 + formData.annualReturnRate, 1 / 12) - 1;

    const futureValue = formData.monthlyInvestment *
      ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);

    setResult(`Estimated Lump Sum at Age 18: ₹${futureValue.toFixed(2)}`);
  };

  return (
    <div className="calc-container">
      <h2>Child Savings Plan Calculator</h2>
      <h3>Child details</h3>

      <div className="form-group">
        <input type="text" placeholder="Enter Child's Name" name="childName" value={formData.childName} onChange={handleChange} />
        <input type="date" name="childDob" value={formData.childDob} onChange={handleChange} />
      </div>

      <div className="gender-options">
        <label><input type="radio" name="gender" value="Male" checked={formData.gender === 'Male'} onChange={handleChange} /> Male</label>
        <label><input type="radio" name="gender" value="Female" checked={formData.gender === 'Female'} onChange={handleChange} /> Female</label>
        <label><input type="radio" name="gender" value="Other" checked={formData.gender === 'Other'} onChange={handleChange} /> Other</label>
      </div>

      <div className="form-group">
        <h3>Parent details</h3>
        <input type="date" placeholder="Date of Birth" name="dob" value={formData.dob} onChange={handleChange} />
        <select name="income" value={formData.income} onChange={handleChange}>
          <option value="">Annual Income</option>
          <option value="below_5">Below ₹5 Lakhs</option>
          <option value="5to10">₹5-10 Lakhs</option>
          <option value="10plus">Above ₹10 Lakhs</option>
        </select>
      </div>

      <div className="form-group">
        <input type="text" placeholder="10 digit mobile number" name="mobile" value={formData.mobile} onChange={handleChange} />
        <input type="email" placeholder="Enter Your Email ID" name="email" value={formData.email} onChange={handleChange} />
      </div>

      <div className="form-group">
        <select name="qualification" value={formData.qualification} onChange={handleChange}>
          <option value="">Qualification</option>
          <option value="graduate">Graduate & above</option>
          <option value="diploma">Diploma</option>
          <option value="school">School Level</option>
        </select>
        <select name="occupation" value={formData.occupation} onChange={handleChange}>
          <option value="">Occupation</option>
          <option value="salaried">Salaried</option>
          <option value="self">Self Employed</option>
          <option value="others">Others</option>
        </select>
      </div>

      <div className="form-group">
        <input type="text" placeholder="Enter your pincode" name="pincode" value={formData.pincode} onChange={handleChange} />
        <input type="text" placeholder="City" name="city" value={formData.city} onChange={handleChange} />
      </div>

      <div className="checkbox-group">
        <label>
          <input type="checkbox" name="consent" checked={formData.consent} onChange={handleChange} />
          I agree to the terms and conditions.
        </label>
      </div>

      <button className="calc-button" onClick={calculateReturns}>Let's Calculate Returns</button>

      {result && <div className="result">{result}</div>}
    </div>
  );
};

export default ChildSavingsCalculator;
