import React from "react";
import bgimg from "../../../assets/policybg-1.png";
import contentimg from "../../../assets/contentimg.jpg";
import "./Policies.css";

const Content1 = () => {
  return (
    <div>
      <div className="wholediv">
        <div className="textdiv">
          <div>
            <h1>Why do you need a Child plan?</h1>
            <p>
              Your child’s future depends a lot on how well-prepared you are
              financially for the future. Your child’s needs will change with
              time, but your responsibilities will not.
            </p>
          </div>
          <div>
            <p>
              Build an adequate amount of fund by investing a nominal amount
              regularly
            </p>
            <p>
              Flexible withdrawals and payout features13,17 to take care of any
              expenses related to your child’s growth at key milestones
            </p>
            <p>
              Child’s education remains secured even in your absence18 as the
              policy continues and the maturity amount gets paid to your child
            </p>
          </div>
        </div>
        <div className="bgdiv">
            <img src={contentimg} alt="" />
        </div>
      </div>
    </div>
  );
};

export default Content1;

