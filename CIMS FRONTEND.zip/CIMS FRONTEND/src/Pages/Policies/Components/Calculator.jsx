import React, { useState } from "react";
import Familyimg from "../../../assets/familyimage.png";
import "./Policies.css";

const Calculator = () => {
  // const [formData, setFormData] = useState({
  //   childName: "",
  //   childDOB: "",
  //   gender: "",
  //   dob: "",
  //   income: "",
  //   mobile: "",
  //   email: "",
  //   qualification: "",
  //   occupation: "",
  //   pincode: "",
  //   city: "",
  //   agreement: false,
  // });

  // const handleChange = (e) => {
  //   const { name, value, type, checked } = e.target;
  //   setFormData({
  //     ...formData,
  //     [name]: type === "checkbox" ? checked : value,
  //   });
  // };

  // const handleSubmit = (e) => {
  //   e.preventDefault();
  //   console.log("Form Data Submitted:", formData);
  // };

  return (
    <div className="policy-first">
      <div className="calculator-wrapper">
        <div className="policy-div1">
          <h2>Child Saving Plan</h2>
          <h1>
            Build wealth for your child’s future
            <br />
            with savings insurance plan
          </h1>
          <h3>
            Your child’s future depends a lot
            <br />
            on how well-prepared you are
          </h3>
          <h2>Plan Benefit’s</h2>
          <div className="benefitdiv">
            <div className="benefitdiv1">
              <p>Company acts as Parent for your child</p>
              <p>Life cover amount</p>
            </div>
            <div className="benefitdiv2">
              <p>Easy withdrawal in times of need</p>
              <p>Family income</p>
            </div>
          </div>
        </div>


        <div className="policy-image-div">
          <img src={Familyimg} alt="Family" />
        </div>

        {/* <div className="form-container">
          <form className="calculator-form" onSubmit={handleSubmit}>
            <h2>Child Savings Plan Calculator</h2>

            <div className="form-section">
              <h3>Child Details</h3>
              <input
                type="text"
                name="childName"
                placeholder="Enter Child's Name"
                value={formData.childName}
                onChange={handleChange}
                required
              />
              <input
                type="date"
                name="childDOB"
                value={formData.childDOB}
                onChange={handleChange}
                required
              />

              <label className="label">Gender</label>
              <div className="gender-group">
                <button
                  type="button"
                  className={formData.gender === "Male" ? "active" : ""}
                  onClick={() => setFormData({ ...formData, gender: "Male" })}
                >
                  Male
                </button>
                <button
                  type="button"
                  className={formData.gender === "Female" ? "active" : ""}
                  onClick={() => setFormData({ ...formData, gender: "Female" })}
                >
                  Female
                </button>
                <button
                  type="button"
                  className={formData.gender === "Other" ? "active" : ""}
                  onClick={() => setFormData({ ...formData, gender: "Other" })}
                >
                  Other
                </button>
              </div>
            </div>

            <div className="form-section">
              <h3>Parent Details</h3>
              <input
                type="date"
                name="dob"
                value={formData.dob}
                onChange={handleChange}
                required
              />
              <select
                name="income"
                value={formData.income}
                onChange={handleChange}
                required
              >
                <option value="">Annual Income</option>
                <option value="0-5L">0 - 5 Lakhs</option>
                <option value="5-10L">5 - 10 Lakhs</option>
                <option value="10L+">10 Lakhs+</option>
              </select>
              <input
                type="text"
                name="mobile"
                placeholder="10 digit mobile number"
                value={formData.mobile}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Enter Your Email ID"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <select
                name="qualification"
                value={formData.qualification}
                onChange={handleChange}
                required
              >
                <option value="">Qualification</option>
                <option value="Graduate">Graduate & above</option>
                <option value="Undergraduate">Undergraduate</option>
                <option value="Other">Other</option>
              </select>
              <select
                name="occupation"
                value={formData.occupation}
                onChange={handleChange}
                required
              >
                <option value="">Occupation</option>
                <option value="Salaried">Salaried</option>
                <option value="Self-employed">Self-employed</option>
                <option value="Other">Other</option>
              </select>
              <input
                type="text"
                name="pincode"
                placeholder="Enter your pincode"
                value={formData.pincode}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="city"
                placeholder="City"
                value={formData.city}
                onChange={handleChange}
                required
              />
            </div>

            <div className="agreement">
              <input
                type="checkbox"
                name="agreement"
                checked={formData.agreement}
                onChange={handleChange}
                required
              />
              <label>
                By submitting my details, I override my NDNC registration and
                authorize you to contact me.
              </label>
            </div>

            <button type="submit" className="submit-btn">
              Let's Calculate Returns
            </button>
          </form>
        </div> */}
      </div>
    </div>
  );
};

export default Calculator;
