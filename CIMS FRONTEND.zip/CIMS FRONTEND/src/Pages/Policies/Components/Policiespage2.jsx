// // import React, { useState } from 'react';
// // import insurance1 from "../../../assets/insurance1.jpg";
// // import "./Policies.css";

// // const Policiespage2 = () => {
// //   const [formData, setFormData] = useState({
// //     childName: "",
// //     childDOB: "",
// //     gender: "",
// //     dob: "",
// //     income: "",
// //     mobile: "",
// //     email: "",
// //     qualification: "",
// //     occupation: "",
// //     pincode: "",
// //     city: "",
// //     yearlyInvestment: "",
// //     agreement: false,
// //   });

// //   const handleChange = (e) => {
// //     const { name, value, type, checked } = e.target;
// //     setFormData({
// //       ...formData,
// //       [name]: type === "checkbox" ? checked : value,
// //     });
// //   };

// //   const calculateReturns = () => {
// //     const birthDate = new Date(formData.childDOB);
// //     const today = new Date();
// //     const age = today.getFullYear() - birthDate.getFullYear();
// //     const yearsToInvest = 18 - age;
// //     const P = parseFloat(formData.yearlyInvestment);
// //     const r = 0.08; // 8% annual return

// //     if (yearsToInvest > 0 && !isNaN(P)) {
// //       const FV = P * (((1 + r) ** yearsToInvest - 1) / r);
// //       return FV.toFixed(2);
// //     }
// //     return 0;
// //   };

// //   const handleSubmit = (e) => {
// //     e.preventDefault();
// //     const result = calculateReturns();
// //     console.log("Form Data Submitted:", formData);
// //     alert(`Estimated maturity amount by age 18: ₹${result}`);
// //   };

// //   return (
//     // <div>
//     //   <div>
//     //     <div>
//     //       <h1>Policies we offer</h1>
//     //       <h2>Guardian Shield</h2>
//     //       <p>
//     //         Guardian Shield is a contract that helps cover medical expenses,
//     //         including doctor visits, hospital stays, and prescriptions. It offers
//     //         financial protection. Offers supplemental health insurance products
//     //         designed to cover gaps in existing health insurance plans. Offerings
//     //         include: Supplemental Health Insurance: Covers out-of-pocket medical
//     //         expenses like deductibles and co-payments. Accidental Death Insurance:
//     //         Provides financial support in the event of accidental death, serving
//     //         as an affordable alternative or supplement to traditional life
//     //         insurance.
//     //       </p>
//     //     </div>
//     //     <div>
//     //       <img src={insurance1} alt="" />
//     //     </div>
//     //   </div>

// //       <div className="form-container">
// //         <form className="calculator-form" onSubmit={handleSubmit}>
// //           <h2>Child Savings Plan Calculator</h2>

// //           <div className="form-section">
// //             <h3>Child Details</h3>
// //             <input
// //               type="text"
// //               name="childName"
// //               placeholder="Enter Child's Name"
// //               value={formData.childName}
// //               onChange={handleChange}
// //               required
// //             />
// //             <input
// //               type="date"
// //               name="childDOB"
// //               value={formData.childDOB}
// //               onChange={handleChange}
// //               required
// //             />

// //             <label className="label">Gender</label>
// //             <div className="gender-group">
// //               <button
// //                 type="button"
// //                 className={formData.gender === "Male" ? "active" : ""}
// //                 onClick={() => setFormData({ ...formData, gender: "Male" })}
// //               >
// //                 Male
// //               </button>
// //               <button
// //                 type="button"
// //                 className={formData.gender === "Female" ? "active" : ""}
// //                 onClick={() => setFormData({ ...formData, gender: "Female" })}
// //               >
// //                 Female
// //               </button>
// //               <button
// //                 type="button"
// //                 className={formData.gender === "Other" ? "active" : ""}
// //                 onClick={() => setFormData({ ...formData, gender: "Other" })}
// //               >
// //                 Other
// //               </button>
// //             </div>
// //           </div>

// //           <div className="form-section">
// //             <h3>Parent Details</h3>
// //             <input
// //               type="date"
// //               name="dob"
// //               value={formData.dob}
// //               onChange={handleChange}
// //               required
// //             />
// //             <select
// //               name="income"
// //               value={formData.income}
// //               onChange={handleChange}
// //               required
// //             >
// //               <option value="">Annual Income</option>
// //               <option value="0-5L">0 - 5 Lakhs</option>
// //               <option value="5-10L">5 - 10 Lakhs</option>
// //               <option value="10L+">10 Lakhs+</option>
// //             </select>
// //             <input
// //               type="text"
// //               name="mobile"
// //               placeholder="10 digit mobile number"
// //               value={formData.mobile}
// //               onChange={handleChange}
// //               required
// //             />
// //             <input
// //               type="email"
// //               name="email"
// //               placeholder="Enter Your Email ID"
// //               value={formData.email}
// //               onChange={handleChange}
// //               required
// //             />
// //             <select
// //               name="qualification"
// //               value={formData.qualification}
// //               onChange={handleChange}
// //               required
// //             >
// //               <option value="">Qualification</option>
// //               <option value="Graduate">Graduate & above</option>
// //               <option value="Undergraduate">Undergraduate</option>
// //               <option value="Other">Other</option>
// //             </select>
// //             <select
// //               name="occupation"
// //               value={formData.occupation}
// //               onChange={handleChange}
// //               required
// //             >
// //               <option value="">Occupation</option>
// //               <option value="Salaried">Salaried</option>
// //               <option value="Self-employed">Self-employed</option>
// //               <option value="Other">Other</option>
// //             </select>
// //             <input
// //               type="text"
// //               name="pincode"
// //               placeholder="Enter your pincode"
// //               value={formData.pincode}
// //               onChange={handleChange}
// //               required
// //             />
// //             <input
// //               type="text"
// //               name="city"
// //               placeholder="City"
// //               value={formData.city}
// //               onChange={handleChange}
// //               required
// //             />
// //             <input
// //               type="number"
// //               name="yearlyInvestment"
// //               placeholder="Yearly Investment Amount"
// //               value={formData.yearlyInvestment}
// //               onChange={handleChange}
// //               required
// //             />
// //           </div>

// //           <div className="agreement">
// //             <input
// //               type="checkbox"
// //               name="agreement"
// //               checked={formData.agreement}
// //               onChange={handleChange}
// //               required
// //             />
// //             <label>
// //               By submitting my details, I override my NDNC registration and
// //               authorize you to contact me.
// //             </label>
// //           </div>

// //           <button type="submit" className="submit-btn">
// //             Let's Calculate Returns
// //           </button>
// //         </form>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Policiespage2;

// import React, { useState } from "react";
// import "./Policies.css";
// import insurance1 from "../../../assets/insurance1.jpg";


// const Policiespage2 = () => {
//   const [formData, setFormData] = useState({
//     initialInvestment: "",
//     annualRate: "",
//     durationYears: "",
//   });

//   const [futureValue, setFutureValue] = useState(null);
//   const [errors, setErrors] = useState({});

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const validate = () => {
//     const newErrors = {};
//     const { initialInvestment, annualRate, durationYears } = formData;

//     if (!initialInvestment || isNaN(initialInvestment) || Number(initialInvestment) <= 0) {
//       newErrors.initialInvestment = "Enter a valid investment amount";
//     }

//     if (!annualRate || isNaN(annualRate) || Number(annualRate) < 0 || Number(annualRate) > 100) {
//       newErrors.annualRate = "Enter a valid rate between 0 and 100";
//     }

//     if (!durationYears || isNaN(durationYears) || !Number.isInteger(Number(durationYears)) || Number(durationYears) <= 0) {
//       newErrors.durationYears = "Enter a valid number of years";
//     }

//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (!validate()) return;

//     const PV = parseFloat(formData.initialInvestment);
//     const r = parseFloat(formData.annualRate) / 100;
//     const n = parseInt(formData.durationYears);

//     const FV = PV * Math.pow(1 + r, n);
//     setFutureValue(FV.toFixed(2));
//   };

//   return (
    // <div>
    //   <div>
    //     <div>
    //       <h1>Policies we offer</h1>
    //       <h2>Guardian Shield</h2>
    //       <p>
    //         Guardian Shield is a contract that helps cover medical expenses,
    //         including doctor visits, hospital stays, and prescriptions. It offers
    //         financial protection. Offers supplemental health insurance products
    //         designed to cover gaps in existing health insurance plans. Offerings
    //         include: Supplemental Health Insurance: Covers out-of-pocket medical
    //         expenses like deductibles and co-payments. Accidental Death Insurance:
    //         Provides financial support in the event of accidental death, serving
    //         as an affordable alternative or supplement to traditional life
    //         insurance.
    //       </p>
    //     </div>
    //     <div>
    //       <img src={insurance1} alt="" />
    //     </div>
    //   </div>

//     <div className="calculator-container">
//       <form className="calculator-form" onSubmit={handleSubmit}>
//         <h2>Child Savings Plan Calculator</h2>

//         <div className="form-group">
//           <label>Initial Investment (₹)</label>
//           <input
//             type="text"
//             name="initialInvestment"
//             value={formData.initialInvestment}
//             onChange={handleChange}
//           />
//           {errors.initialInvestment && <span className="error">{errors.initialInvestment}</span>}
//         </div>

//         <div className="form-group">
//           <label>Annual Interest Rate (%)</label>
//           <input
//             type="text"
//             name="annualRate"
//             value={formData.annualRate}
//             onChange={handleChange}
//           />
//           {errors.annualRate && <span className="error">{errors.annualRate}</span>}
//         </div>

//         <div className="form-group">
//           <label>Duration (Years)</label>
//           <input
//             type="text"
//             name="durationYears"
//             value={formData.durationYears}
//             onChange={handleChange}
//           />
//           {errors.durationYears && <span className="error">{errors.durationYears}</span>}
//         </div>

//         <button type="submit" className="submit-btn">Calculate</button>
//       </form>

//       {futureValue && (
//         <div className="result">
//           <h3>Future Value: ₹{futureValue}</h3>
//         </div>
//       )}
//     </div>
//     </div>
//   );
// };

// export default Policiespage2;

import React from 'react';
import './Policies.css';
import insurance1 from "../../../assets/insurance1.jpg";
import ChildSavingsCalculator from './ChildSavingsCalculator';
import { Link } from 'react-router-dom';

const Policiespage2 = () => {
  return (
    <div className="policies-container">
      <div className="content-wrapper">
        <section className="policy-info">
          <h1>Policies we offer</h1>
          <h2>Guardian Shield</h2>
          <p>
            Guardian Shield is a contract that helps cover medical expenses,
            including doctor visits, hospital stays, and prescriptions. It offers
            financial protection. Offers supplemental health insurance products
            designed to cover gaps in existing health insurance plans. Offerings
            include:
            <ul>
              <li>Supplemental Health Insurance: Covers out-of-pocket medical expenses like deductibles and co-payments.</li>
              <li>Accidental Death Insurance: Provides financial support in the event of accidental death, serving as an affordable alternative or supplement to traditional life insurance.</li>
            </ul>
          </p>
          <Link to="/login">Apply Now &#x27F6;</Link><br />
          <a href="/Guardian_Shield_Brochure.pdf" target="_blank" rel="noopener noreferrer">
            View Guardian Shield Brochure &#x27F6;
          </a>
          <img src={insurance1} alt="" />
        </section>

        <section className="calculator-wrapper">
          <ChildSavingsCalculator />
        </section>
      </div>
    </div>
  );
};

export default Policiespage2;

