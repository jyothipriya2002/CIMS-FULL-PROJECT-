import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Gateway.css';

const products = [
  {
    id: 1,
    name: 'BrightPath Education Shield',
    description: 'Essential coverage for your family with basic protection',
    price: 4000,
    features: ['Fire & lightning', 'Natural disasters', 'Theft protection', 'Basic liability'],
    popular: false,
    icon: '🏠'
  },
  {
    id: 2,
    name: 'EduHealth Shield',
    description: 'Comprehensive coverage for your home and belongings',
    price: 6000,
    features: ['Full property coverage', 'Personal belongings', 'Temporary living expenses', 'Enhanced liability'],
    popular: true,
    icon: '🛡️'
  },
  {
    id: 3,
    name: 'Guardian Shield',
    description: 'Complete protection with premium benefits',
    price: 5000,
    features: ['Full coverage', 'High-value items', 'Identity theft', 'Legal expenses'],
    popular: false,
    icon: '👑'
  },
  
];

const Gateway = () => {
  const navigate = useNavigate();

  const handlePayment = (productId, price) => {
    navigate(`/payment/${productId}?amount=${price}`);
  };

  return (
    <div className="home-container">
      <div className="header-section">
        <h1>Child Insurance Plans</h1>
        <p className="subtitle">Protect your Child with our comprehensive insurance solutions</p>
      </div>
      
      <div className="products-grid">
        {products.map((product) => (
          <div key={product.id} className={`product-card ${product.popular ? 'popular' : ''}`}>
            {product.popular && <div className="popular-badge">Most Popular</div>}
            <div className="card-header">
              <span className="icon">{product.icon}</span>
              <h2>{product.name}</h2>
            </div>
            <p className="description">{product.description}</p>
            <div className="features">
              <h3>Coverage Includes:</h3>
              <ul>
                {product.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>
            <div className="price-section">
              <div className="price">₹{product.price}</div>
              <div className="price-period">per year</div>
            </div>
            <button 
              onClick={() => handlePayment(product.id, product.price)}
              className={`buy-button ${product.popular ? 'popular-button' : ''}`}
            >
              Get Protected
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Gateway; 