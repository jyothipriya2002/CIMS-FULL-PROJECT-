import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import './Payment.css';

const Payment = () => {
  const { productId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const amount = parseFloat(searchParams.get('amount'));

  useEffect(() => {
    loadScript('https://checkout.razorpay.com/v1/checkout.js');
  }, []);

  const loadScript = (src) => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const updatePaymentStatus = async (razorpayOrderId, status) => {
    try {
      const response = await axios.post('http://localhost:9094/api/payments/update-status', {
        razorpayOrderId,
        status
      });
      return response.data;
    } catch (error) {
      console.error('Payment status update error:', error);
      throw error;
    }
  };

  const handlePayment = async () => {
    try {
      setLoading(true);
      const userId = parseInt(localStorage.getItem('userId') || '1');

      if (!productId || isNaN(userId) || isNaN(amount)) {
        toast.error('Invalid payment details');
        setLoading(false);
        return;
      }

      const response = await axios.post('http://localhost:9094/api/payments/create', {
        policyId: parseInt(productId),
        userId,
        amount
      });

      const { razorpayOrderId, amountPaid } = response.data;

      const options = {
        key: 'rzp_test_LyvbhJl1AcRLl9',
        amount: amountPaid * 100,
        currency: 'INR',
        name: 'Insurance Payment',
        description: 'Payment for Insurance Policy',
        order_id: razorpayOrderId,
        handler: async function (response) {
          try {
            const verifyResponse = await axios.post('http://localhost:9094/api/payments/verify', {
              razorpayOrderId,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature
            });

            if (verifyResponse.data.verified) {
              const updatedPayment = await updatePaymentStatus(razorpayOrderId, 'Success');
              toast.success('Payment Successful!');
              setTimeout(() => navigate('/parent-dashboard', { replace: true }), 1000);
            } else {
              throw new Error('Payment verification failed');
            }
          } catch (error) {
            await updatePaymentStatus(razorpayOrderId, 'Failed');
            toast.error('Payment verification failed');
          }
        },
        prefill: {
          name: localStorage.getItem('userName') || 'Test User',
          email: localStorage.getItem('userEmail') || 'test@example.com'
        },
        theme: { color: '#3399cc' },
        modal: {
          ondismiss: async () => {
            await updatePaymentStatus(razorpayOrderId, 'Failed');
            toast.error('Payment was cancelled');
          }
        }
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error('Payment initialization error:', error);
      toast.error('Payment initialization failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="payment-container">
      <div className="payment-header">
        <h1>Secure Payment</h1>
        <p className="subtitle">Complete your insurance purchase securely</p>
      </div>
      <div className="payment-card">
        <div className="payment-details">
          <div className="detail-item"><span className="label">Policy ID:</span><span className="value">{productId}</span></div>
          <div className="detail-item"><span className="label">Amount:</span><span className="value">₹{amount}</span></div>
        </div>
        <div className="security-info">
          <div className="security-item"><span className="security-icon">🔒</span><span>Secure Payment</span></div>
          <div className="security-item"><span className="security-icon">🛡️</span><span>SSL Encrypted</span></div>
        </div>
        <button onClick={handlePayment} disabled={loading} className={`pay-button ${loading ? 'loading' : ''}`}>
          {loading ? 'Processing...' : 'Pay Now'}
        </button>
        <div className="payment-footer">
          <p>By proceeding, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></p>
        </div>
      </div>
    </div>
  );
};

export default Payment;
