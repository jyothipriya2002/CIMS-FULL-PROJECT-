// // // import React, { useState, useEffect } from 'react';
// // // import { useNavigate } from 'react-router-dom';
// // // import axios from 'axios';
// // // import 'bootstrap/dist/css/bootstrap.min.css';
// // // import { 
// // //   FaUsers, 
// // //   FaChild, 
// // //   FaFileContract, 
// // //   FaTrash, 
// // //   FaSignOutAlt,
// // //   FaFileAlt,
// // //   FaHome,
// // //   FaBars
// // // } from 'react-icons/fa';

// // // const AdminDashboard = () => {
// // //   const [activeTab, setActiveTab] = useState('overview');
// // //   const [plans, setPlans] = useState([]);
// // //   const [parents, setParents] = useState([]);
// // //   const [children, setChildren] = useState([]);
// // //   const [claims, setClaims] = useState([]);
// // //   const [newPlan, setNewPlan] = useState({
// // //     name: '',
// // //     monthlyPremium: '',
// // //     coverageMonths: ''
// // //   });
// // //   const [dashboardStats, setDashboardStats] = useState({
// // //     totalParents: 0,
// // //     totalChildren: 0,
// // //     totalPlans: 0,
// // //     pendingClaims: 0
// // //   });
// // //   const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
// // //   const navigate = useNavigate();

// // //   useEffect(() => {
// // //     const token = localStorage.getItem('adminToken');
// // //     const adminData = localStorage.getItem('adminData');
    
// // //     if (!token || !adminData) {
// // //       navigate('/');
// // //       return;
// // //     }
    
// // //     const fetchData = async () => {
// // //       await fetchParents();
// // //       await fetchChildren();
// // //       await fetchPlans();
// // //       await fetchPendingClaims();
// // //     };
// // //     fetchData();
// // //   }, [navigate]);

// // //   const fetchPlans = async () => {
// // //     try {
// // //       const response = await axios.get('http://localhost:9094/api/admin/getallplan');
// // //       setPlans(response.data);
// // //       updateDashboardStats('totalPlans', response.data.length);
// // //     } catch (error) {
// // //       console.error('Error fetching plans:', error);
// // //       alert('Failed to fetch plans');
// // //     }
// // //   };

// // //   const fetchParents = async () => {
// // //     try {
// // //       const token = localStorage.getItem('adminToken');
// // //       const response = await axios.get('http://localhost:9094/api/admin/getAllParent', {
// // //         headers: {
// // //           'Authorization': `Bearer ${token}`,
// // //           'Content-Type': 'application/json'
// // //         }
// // //       });
      
// // //       if (response.data) {
// // //         // Ensure we're handling both array and single object responses
// // //         const parentData = Array.isArray(response.data) ? response.data : [response.data];
// // //         setParents(parentData);
// // //         updateDashboardStats('totalParents', parentData.length);
// // //         console.log('Fetched parents:', parentData);
// // //       } else {
// // //         console.error('Invalid response format:', response.data);
// // //         alert('Received invalid data format from server');
// // //       }
// // //     } catch (error) {
// // //       console.error('Error fetching parents:', error);
// // //       if (error.response) {
// // //         alert(`Failed to fetch parents: ${error.response.data.message || 'Server error'}`);
// // //       } else {
// // //         alert('Failed to fetch parents. Please check your network connection.');
// // //       }
// // //     }
// // //   };

// // //   const fetchChildren = async () => {
// // //     try {
// // //       const token = localStorage.getItem('adminToken');
// // //       const response = await axios.get('http://localhost:9094/api/admin/getAllChild', {
// // //         headers: {
// // //           'Authorization': `Bearer ${token}`,
// // //           'Content-Type': 'application/json'
// // //         }
// // //       });
      
// // //       if (response.data) {
// // //         // Ensure we're handling both array and single object responses
// // //         const childData = Array.isArray(response.data) ? response.data : [response.data];
// // //         setChildren(childData);
// // //         updateDashboardStats('totalChildren', childData.length);
// // //         console.log('Fetched children:', childData);
// // //       } else {
// // //         console.error('Invalid response format:', response.data);
// // //         alert('Received invalid data format from server');
// // //       }
// // //     } catch (error) {
// // //       console.error('Error fetching children:', error);
// // //       if (error.response) {
// // //         alert(`Failed to fetch children: ${error.response.data.message || 'Server error'}`);
// // //       } else {
// // //         alert('Failed to fetch children. Please check your network connection.');
// // //       }
// // //     }
// // //   };

// // //   const fetchPendingClaims = async () => {
// // //     try {
// // //       const response = await axios.get('http://localhost:9094/api/claims/pending');
// // //       setClaims(response.data);
// // //       updateDashboardStats('pendingClaims', response.data.length);
// // //     } catch (error) {
// // //       console.error('Error fetching claims:', error);
// // //       alert('Failed to fetch claims');
// // //     }
// // //   };

// // //   const updateDashboardStats = (key, value) => {
// // //     setDashboardStats(prev => ({
// // //       ...prev,
// // //       [key]: value
// // //     }));
// // //   };

// // //   const handleAddPlan = async (e) => {
// // //     e.preventDefault();
// // //     try {
// // //       const payload = {
// // //         name: newPlan.name,
// // //         monthlyPremium: parseFloat(newPlan.monthlyPremium),
// // //         coverageMonths: parseInt(newPlan.coverageMonths, 10)
// // //       };
// // //       await axios.post('http://localhost:9094/api/admin/addplan', payload);
// // //       alert('Plan added successfully');
// // //       setNewPlan({ name: '', monthlyPremium: '', coverageMonths: '' });
// // //       fetchPlans();
// // //     } catch (error) {
// // //       console.error('Error adding plan:', error);
// // //       alert('Failed to add plan: ' + (error.response?.data?.message || 'Server error'));
// // //     }
// // //   };

// // //   const handleDeletePlan = async (plan) => {
// // //     if (window.confirm('Are you sure you want to delete this plan?')) {
// // //       try {
// // //         await axios.post('http://localhost:9094/api/admin/delplan', plan);
// // //         alert('Plan deleted successfully');
// // //         fetchPlans();
// // //       } catch (error) {
// // //         console.error('Error deleting plan:', error);
// // //         alert('Failed to delete plan: ' + (error.response?.data?.message || 'Server error'));
// // //       }
// // //     }
// // //   };

// // //   const handleLogout = () => {
// // //     localStorage.removeItem('adminToken');
// // //     localStorage.removeItem('adminData');
// // //     navigate('/');
// // //   };

// // //   const toggleSidebar = () => {
// // //     setSidebarCollapsed(!sidebarCollapsed);
// // //   };

// // //   const renderContent = () => {
// // //     switch (activeTab) {
// // //       case 'overview':
// // //         return (
// // //           <div className="row g-4">
// // //             <div style={{ width: 'fit-content' }}>
// // //               <div className="card bg-primary text-white h-100">
// // //                 <div className="card-body">
// // //                   <div className="d-flex justify-content-between align-items-center">
// // //                     <div>
// // //                       <h6 className="card-title mb-3">Total Parents</h6>
// // //                       <h2 className="mb-0">{dashboardStats.totalParents}</h2>
// // //                     </div>
// // //                     <FaUsers size={24} />
// // //                   </div>
// // //                 </div>
// // //               </div>
// // //             </div>
// // //             <div style={{ width: 'fit-content' }}>
// // //               <div className="card bg-success text-white h-100">
// // //                 <div className="card-body">
// // //                   <div className="d-flex justify-content-between align-items-center">
// // //                     <div>
// // //                       <h6 className="card-title mb-3">Total Children</h6>
// // //                       <h2 className="mb-0">{dashboardStats.totalChildren}</h2>
// // //                     </div>
// // //                     <FaChild size={24} />
// // //                   </div>
// // //                 </div>
// // //               </div>
// // //             </div>
// // //             <div style={{ width: 'fit-content' }}>
// // //               <div className="card bg-info text-white h-100">
// // //                 <div className="card-body">
// // //                   <div className="d-flex justify-content-between align-items-center">
// // //                     <div>
// // //                       <h6 className="card-title mb-3">Total Plans</h6>
// // //                       <h2 className="mb-0">{dashboardStats.totalPlans}</h2>
// // //                     </div>
// // //                     <FaFileAlt size={24} />
// // //                   </div>
// // //                 </div>
// // //               </div>
// // //             </div>
// // //             <div style={{ width: 'fit-content' }}>
// // //               <div className="card bg-warning text-white h-100">
// // //                 <div className="card-body">
// // //                   <div className="d-flex justify-content-between align-items-center">
// // //                     <div>
// // //                       <h6 className="card-title mb-3">Pending Claims</h6>
// // //                       <h2 className="mb-0">{dashboardStats.pendingClaims}</h2>
// // //                     </div>
// // //                     <FaFileContract size={24} />
// // //                   </div>
// // //                 </div>
// // //               </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       case 'parents':
// // //         return (
// // //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// // //             <div className="card-body">
// // //               <h5 className="card-title">Parent Details</h5>
// // //               <div className="table-responsive">
// // //                 <table className="table table-hover">
// // //                   <thead>
// // //                     <tr>
// // //                       <th>Parent Name</th>
// // //                       <th>Parent ID</th>
// // //                       <th>Parent Email</th>
// // //                       <th>Parent Number</th>
// // //                       <th>Children</th>
// // //                     </tr>
// // //                   </thead>
// // //                   <tbody>
// // //                     {parents.length > 0 ? (
// // //                       parents.map((parent) => (
// // //                         <tr key={parent.parentEmailId || parent.email}>
// // //                           <td>{parent.parentName}</td>
// // //                           <td>{parent.parentId || parent.parent_Id || 'N/A'}</td>
// // //                           <td>{parent.parentEmailId || parent.email}</td>
// // //                           <td>{parent.contactNumber || parent.phoneNumber || 'N/A'}</td>
// // //                           <td>
// // //                             {parent.children && parent.children.length > 0
// // //                               ? parent.children.map(child => child.childName).join(', ')
// // //                               : parent.childrenNames && parent.childrenNames.length > 0
// // //                               ? parent.childrenNames.join(', ')
// // //                               : 'No children'}
// // //                           </td>
// // //                         </tr>
// // //                       ))
// // //                     ) : (
// // //                       <tr>
// // //                         <td colSpan="5" className="text-center">No parents found</td>
// // //                       </tr>
// // //                     )}
// // //                   </tbody>
// // //                 </table>
// // //               </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       case 'children':
// // //         return (
// // //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// // //             <div className="card-body">
// // //               <h5 className="card-title">Children Details</h5>
// // //               <div className="table-responsive">
// // //                 <table className="table table-hover">
// // //                   <thead>
// // //                     <tr>
// // //                       <th>Child Name</th>
// // //                       <th>Child ID</th>
// // //                       <th>Child Age</th>
// // //                       <th>Child Gender</th>
// // //                       <th>Date of Birth</th>
// // //                     </tr>
// // //                   </thead>
// // //                   <tbody>
// // //                     {children.length > 0 ? (
// // //                       children.map((child) => (
// // //                         <tr key={child.childId || child.id}>
// // //                           <td>{child.childName || 'N/A'}</td>
// // //                           <td>{child.childId || child.id || 'N/A'}</td>
// // //                           <td>{child.childAge || child.age || 'N/A'}</td>
// // //                           <td>{child.childGender || child.gender || 'N/A'}</td>
// // //                           <td>{child.dateOfBirth || 'N/A'}</td>
// // //                         </tr>
// // //                       ))
// // //                     ) : (
// // //                       <tr>
// // //                         <td colSpan="5" className="text-center">No children found</td>
// // //                       </tr>
// // //                     )}
// // //                   </tbody>
// // //                 </table>
// // //               </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       case 'plans':
// // //         return (
// // //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// // //             <div className="card-body">
// // //               <h5 className="card-title">Insurance Plans</h5>
              
// // //               <div className="mb-4">
// // //                 <h6>Add New Plan</h6>
// // //                 <form onSubmit={handleAddPlan}>
// // //                   <div className="row">
// // //                     <div className="col-md-4">
// // //                       <div className="mb-3">
// // //                         <label htmlFor="name" className="form-label">Plan Name</label>
// // //                         <input
// // //                           type="text"
// // //                           className="form-control"
// // //                           id="name"
// // //                           value={newPlan.name}
// // //                           onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
// // //                           required
// // //                         />
// // //                       </div>
// // //                     </div>
// // //                     <div className="col-md-4">
// // //                       <div className="mb-3">
// // //                         <label htmlFor="monthlyPremium" className="form-label">Monthly Premium (₹)</label>
// // //                         <input
// // //                           type="number"
// // //                           step="0.01"
// // //                           className="form-control"
// // //                           id="monthlyPremium"
// // //                           value={newPlan.monthlyPremium}
// // //                           onChange={(e) => setNewPlan({ ...newPlan, monthlyPremium: e.target.value })}
// // //                           required
// // //                         />
// // //                       </div>
// // //                     </div>
// // //                     <div className="col-md-4">
// // //                       <div className="mb-3">
// // //                         <label htmlFor="coverageMonths" className="form-label">Coverage Months</label>
// // //                         <input
// // //                           type="number"
// // //                           className="form-control"
// // //                           id="coverageMonths"
// // //                           value={newPlan.coverageMonths}
// // //                           onChange={(e) => setNewPlan({ ...newPlan, coverageMonths: e.target.value })}
// // //                           required
// // //                         />
// // //                       </div>
// // //                     </div>
// // //                   </div>
// // //                   <button type="submit" className="btn btn-primary">Add Plan</button>
// // //                 </form>
// // //               </div>

// // //               <h6 className="mt-4">Plans List</h6>
// // //               <div className="table-responsive">
// // //                 <table className="table table-hover">
// // //                   <thead>
// // //                     <tr>
// // //                       <th>Plan ID</th>
// // //                       <th>Plan Name</th>
// // //                       <th>Monthly Premium (₹)</th>
// // //                       <th>Coverage Months</th>
// // //                       <th>Actions</th>
// // //                     </tr>
// // //                   </thead>
// // //                   <tbody>
// // //                     {plans.length > 0 ? (
// // //                       plans.map((plan) => (
// // //                         <tr key={plan.planId}>
// // //                           <td>{plan.planId || 'N/A'}</td>
// // //                           <td>{plan.name || 'N/A'}</td>
// // //                           <td>₹{plan.monthlyPremium || '0.0'}</td>
// // //                           <td>{plan.coverageMonths || '0'}</td>
// // //                           <td>
// // //                             <button
// // //                               className="btn btn-danger btn-sm"
// // //                               onClick={() => handleDeletePlan(plan)}
// // //                             >
// // //                               <FaTrash className="me-1" /> Delete
// // //                             </button>
// // //                           </td>
// // //                         </tr>
// // //                       ))
// // //                     ) : (
// // //                       <tr>
// // //                         <td colSpan="5">No plans found.</td>
// // //                       </tr>
// // //                     )}
// // //                   </tbody>
// // //                 </table>
// // //                 </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       case 'claims':
// // //         return (
// // //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// // //             <div className="card-body">
// // //               <h5 className="card-title">Pending Claims</h5>
// // //               <div className="table-responsive">
// // //                 <table className="table table-hover">
// // //                   <thead>
// // //                     <tr>
// // //                       <th>Claim ID</th>
// // //                       <th>Policy ID</th>
// // //                       <th>Claim Amount</th>
// // //                       <th>Claim Reason</th>
// // //                       <th>Status</th>
// // //                     </tr>
// // //                   </thead>
// // //                   <tbody>
// // //                     {claims.length > 0 ? (
// // //                       claims.map((claim) => (
// // //                         <tr key={claim.claimId}>
// // //                           <td>{claim.claimId}</td>
// // //                           <td>{claim.policyId}</td>
// // //                           <td>₹{claim.claimAmount}</td>
// // //                           <td>{claim.claimReason}</td>
// // //                           <td>
// // //                             <span className="badge bg-warning text-dark">{claim.status}</span>
// // //                           </td>
// // //                         </tr>
// // //                       ))
// // //                     ) : (
// // //                       <tr>
// // //                         <td colSpan="5">No pending claims found.</td>
// // //                       </tr>
// // //                     )}
// // //                   </tbody>
// // //                 </table>
// // //               </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       default:
// // //         return <div>Select a section from the sidebar</div>;
// // //     }
// // //   };

// // //   return (
// // //     <div className="container-fluid">
// // //       <div className="row">
// // //         {/* Sidebar */}
// // //         <div className={`col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse ${sidebarCollapsed ? '' : 'show'}`}
// // //              style={{ minHeight: '100vh', color: 'white' }}>
// // //           <div className="position-sticky pt-3">
// // //             <div className="d-flex justify-content-between align-items-center mb-3 px-3">
// // //               <h4>Admin Panel</h4>
// // //               <button 
// // //                 className="btn btn-link text-white d-md-none" 
// // //                 onClick={toggleSidebar}
// // //               >
// // //                 <FaBars />
// // //               </button>
// // //             </div>
// // //             <ul className="nav flex-column">
// // //               <li className="nav-item">
// // //                 <button 
// // //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'overview' ? 'active' : ''}`}
// // //                   onClick={() => setActiveTab('overview')}
// // //                 >
// // //                   <FaHome className="me-2" /> Dashboard
// // //                 </button>
// // //               </li>
// // //               <li className="nav-item">
// // //                 <button 
// // //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'parents' ? 'active' : ''}`}
// // //                   onClick={() => setActiveTab('parents')}
// // //                 >
// // //                   <FaUsers className="me-2" /> Parents
// // //                 </button>
// // //               </li>
// // //               <li className="nav-item">
// // //                 <button 
// // //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'children' ? 'active' : ''}`}
// // //                   onClick={() => setActiveTab('children')}
// // //                 >
// // //                   <FaChild className="me-2" /> Children
// // //                 </button>
// // //               </li>
// // //               <li className="nav-item">
// // //                 <button 
// // //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'plans' ? 'active' : ''}`}
// // //                   onClick={() => setActiveTab('plans')}
// // //                 >
// // //                   <FaFileAlt className="me-2" /> Insurance Plans
// // //                 </button>
// // //               </li>
// // //               <li className="nav-item">
// // //                 <button 
// // //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'claims' ? 'active' : ''}`}
// // //                   onClick={() => setActiveTab('claims')}
// // //                 >
// // //                   <FaFileContract className="me-2" /> Claims
// // //                 </button>
// // //               </li>
// // //               <li className="nav-item mt-4">
// // //                 <button 
// // //                   className="nav-link btn btn-link text-danger text-start w-100"
// // //                   onClick={handleLogout}
// // //                 >
// // //                   <FaSignOutAlt className="me-2" /> Logout
// // //                 </button>
// // //               </li>
// // //             </ul>
// // //           </div>
// // //         </div>

// // //         {/* Main content */}
// // //         <main className="col-md-9 col-lg-10 px-md-4 py-4">
// // //           <div className="d-flex justify-content-between align-items-center mb-4">
// // //             <h2>
// // //               {activeTab === 'overview' && 'Dashboard Overview'}
// // //               {activeTab === 'parents' && 'Parent Management'}
// // //               {activeTab === 'children' && 'Children Management'}
// // //               {activeTab === 'plans' && 'Insurance Plans'}
// // //               {activeTab === 'claims' && 'Claims Management'}
// // //             </h2>
// // //             <button 
// // //               className="btn btn-outline-secondary d-md-none" 
// // //               onClick={toggleSidebar}
// // //             >
// // //               <FaBars />
// // //             </button>
// // //           </div>

// // //           {renderContent()}
// // //         </main>
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // export default AdminDashboard;



// // import React, { useState, useEffect } from 'react';
// // import { useNavigate } from 'react-router-dom';
// // import axios from 'axios';
// // import 'bootstrap/dist/css/bootstrap.min.css';
// // import { 
// //   FaUsers, 
// //   FaChild, 
// //   FaFileContract, 
// //   FaTrash, 
// //   FaSignOutAlt,
// //   FaFileAlt,
// //   FaHome,
// //   FaBars
// // } from 'react-icons/fa';

// // const AdminDashboard = () => {
// //   const [activeTab, setActiveTab] = useState('overview');
// //   const [plans, setPlans] = useState([]);
// //   const [parents, setParents] = useState([]);
// //   const [children, setChildren] = useState([]);
// //   const [claims, setClaims] = useState([]);
// //   const [newPlan, setNewPlan] = useState({
// //     name: '',
// //     monthlyPremium: '',
// //     coverageMonths: ''
// //   });
// //   const [dashboardStats, setDashboardStats] = useState({
// //     totalParents: 0,
// //     totalChildren: 0,
// //     totalPlans: 0,
// //     pendingClaims: 0
// //   });
// //   const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     const token = localStorage.getItem('adminToken');
// //     const adminData = localStorage.getItem('adminData');
    
// //     if (!token || !adminData) {
// //       navigate('/');
// //       return;
// //     }
    
// //     const fetchData = async () => {
// //       await fetchParents();
// //       await fetchChildren();
// //       await fetchPlans();
// //       await fetchPendingClaims();
// //     };
// //     fetchData();
// //   }, [navigate]);

// //   const fetchPlans = async () => {
// //     try {
// //       const response = await axios.get('http://localhost:9094/api/admin/getallplan');
// //       setPlans(response.data);
// //       updateDashboardStats('totalPlans', response.data.length);
// //     } catch (error) {
// //       console.error('Error fetching plans:', error);
// //       alert('Failed to fetch plans');
// //     }
// //   };

// //   const fetchParents = async () => {
// //     try {
// //       const token = localStorage.getItem('adminToken');
// //       const response = await axios.get('http://localhost:9094/api/admin/getAllParent', {
// //         headers: {
// //           'Authorization': `Bearer ${token}`,
// //           'Content-Type': 'application/json'
// //         }
// //       });
      
// //       if (response.data) {
// //         const parentData = Array.isArray(response.data) ? response.data : [response.data];
// //         setParents(parentData);
// //         updateDashboardStats('totalParents', parentData.length);
// //         console.log('Fetched parents:', parentData);
// //       } else {
// //         console.error('Invalid response format:', response.data);
// //         alert('Received invalid data format from server');
// //       }
// //     } catch (error) {
// //       console.error('Error fetching parents:', error);
// //       if (error.response) {
// //         alert(`Failed to fetch parents: ${error.response.data.message || 'Server error'}`);
// //       } else {
// //         alert('Failed to fetch parents. Please check your network connection.');
// //       }
// //     }
// //   };

// //   const fetchChildren = async () => {
// //     try {
// //       const token = localStorage.getItem('adminToken');
// //       const response = await axios.get('http://localhost:9094/api/admin/getAllChild', {
// //         headers: {
// //           'Authorization': `Bearer ${token}`,
// //           'Content-Type': 'application/json'
// //         }
// //       });
      
// //       if (response.data) {
// //         const childData = Array.isArray(response.data) ? response.data : [response.data];
// //         setChildren(childData);
// //         updateDashboardStats('totalChildren', childData.length);
// //         console.log('Fetched children:', childData);
// //       } else {
// //         console.error('Invalid response format:', response.data);
// //         alert('Received invalid data format from server');
// //       }
// //     } catch (error) {
// //       console.error('Error fetching children:', error);
// //       if (error.response) {
// //         alert(`Failed to fetch children: ${error.response.data.message || 'Server error'}`);
// //       } else {
// //         alert('Failed to fetch children. Please check your network connection.');
// //       }
// //     }
// //   };

// //   const fetchPendingClaims = async () => {
// //     try {
// //       const token = localStorage.getItem('adminToken');
// //       const response = await axios.get('http://localhost:9094/api/claims/pending', {
// //         headers: {
// //           'Authorization': `Bearer ${token}`,
// //           'Content-Type': 'application/json'
// //         }
// //       });
// //       // Ensure response.data is an array
// //       const claimsData = Array.isArray(response.data) ? response.data : [response.data];
// //       setClaims(claimsData);
// //       updateDashboardStats('pendingClaims', claimsData.length);
// //     } catch (error) {
// //       console.error('Error fetching claims:', error);
// //       alert('Failed to fetch claims: ' + (error.response?.data?.message || 'Server error'));
// //     }
// //   };

// //   const updateDashboardStats = (key, value) => {
// //     setDashboardStats(prev => ({
// //       ...prev,
// //       [key]: value
// //     }));
// //   };

// //   const handleAddPlan = async (e) => {
// //     e.preventDefault();
// //     try {
// //       const payload = {
// //         name: newPlan.name,
// //         monthlyPremium: parseFloat(newPlan.monthlyPremium),
// //         coverageMonths: parseInt(newPlan.coverageMonths, 10)
// //       };
// //       await axios.post('http://localhost:9094/api/admin/addplan', payload);
// //       alert('Plan added successfully');
// //       setNewPlan({ name: '', monthlyPremium: '', coverageMonths: '' });
// //       fetchPlans();
// //     } catch (error) {
// //       console.error('Error adding plan:', error);
// //       alert('Failed to add plan: ' + (error.response?.data?.message || 'Server error'));
// //     }
// //   };

// //   const handleDeletePlan = async (plan) => {
// //     if (window.confirm('Are you sure you want to delete this plan?')) {
// //       try {
// //         await axios.post('http://localhost:9094/api/admin/delplan', plan);
// //         alert('Plan deleted successfully');
// //         fetchPlans();
// //       } catch (error) {
// //         console.error('Error deleting plan:', error);
// //         alert('Failed to delete plan: ' + (error.response?.data?.message || 'Server error'));
// //       }
// //     }
// //   };

// //   const handleLogout = () => {
// //     localStorage.removeItem('adminToken');
// //     localStorage.removeItem('adminData');
// //     navigate('/');
// //   };

// //   const toggleSidebar = () => {
// //     setSidebarCollapsed(!sidebarCollapsed);
// //   };

// //   const renderContent = () => {
// //     switch (activeTab) {
// //       case 'overview':
// //         return (
// //           <div className="row g-4">
// //             <div style={{ width: 'fit-content' }}>
// //               <div className="card bg-primary text-white h-100">
// //                 <div className="card-body">
// //                   <div className="d-flex justify-content-between align-items-center">
// //                     <div>
// //                       <h6 className="card-title mb-3">Total Parents</h6>
// //                       <h2 className="mb-0">{dashboardStats.totalParents}</h2>
// //                     </div>
// //                     <FaUsers size={24} />
// //                   </div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div style={{ width: 'fit-content' }}>
// //               <div className="card bg-success text-white h-100">
// //                 <div className="card-body">
// //                   <div className="d-flex justify-content-between align-items-center">
// //                     <div>
// //                       <h6 className="card-title mb-3">Total Children</h6>
// //                       <h2 className="mb-0">{dashboardStats.totalChildren}</h2>
// //                     </div>
// //                     <FaChild size={24} />
// //                   </div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div style={{ width: 'fit-content' }}>
// //               <div className="card bg-info text-white h-100">
// //                 <div className="card-body">
// //                   <div className="d-flex justify-content-between align-items-center">
// //                     <div>
// //                       <h6 className="card-title mb-3">Total Plans</h6>
// //                       <h2 className="mb-0">{dashboardStats.totalPlans}</h2>
// //                     </div>
// //                     <FaFileAlt size={24} />
// //                   </div>
// //                 </div>
// //               </div>
// //             </div>
// //             <div style={{ width: 'fit-content' }}>
// //               <div className="card bg-warning text-white h-100">
// //                 <div className="card-body">
// //                   <div className="d-flex justify-content-between align-items-center">
// //                     <div>
// //                       <h6 className="card-title mb-3">Pending Claims</h6>
// //                       <h2 className="mb-0">{dashboardStats.pendingClaims}</h2>
// //                     </div>
// //                     <FaFileContract size={24} />
// //                   </div>
// //                 </div>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       case 'parents':
// //         return (
// //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// //             <div className="card-body">
// //               <h5 className="card-title">Parent Details</h5>
// //               <div className="table-responsive">
// //                 <table className="table table-hover">
// //                   <thead>
// //                     <tr>
// //                       <th>Parent Name</th>
// //                       <th>Parent ID</th>
// //                       <th>Parent Email</th>
// //                       <th>Parent Number</th>
// //                       <th>Children</th>
// //                     </tr>
// //                   </thead>
// //                   <tbody>
// //                     {parents.length > 0 ? (
// //                       parents.map((parent) => (
// //                         <tr key={parent.parentEmailId || parent.email}>
// //                           <td>{parent.parentName}</td>
// //                           <td>{parent.parentId || parent.parent_Id || 'N/A'}</td>
// //                           <td>{parent.parentEmailId || parent.email}</td>
// //                           <td>{parent.contactNumber || parent.phoneNumber || 'N/A'}</td>
// //                           <td>
// //                             {parent.children && parent.children.length > 0
// //                               ? parent.children.map(child => child.childName).join(', ')
// //                               : parent.childrenNames && parent.childrenNames.length > 0
// //                               ? parent.childrenNames.join(', ')
// //                               : 'No children'}
// //                           </td>
// //                         </tr>
// //                       ))
// //                     ) : (
// //                       <tr>
// //                         <td colSpan="5" className="text-center">No parents found</td>
// //                       </tr>
// //                     )}
// //                   </tbody>
// //                 </table>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       case 'children':
// //         return (
// //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// //             <div className="card-body">
// //               <h5 className="card-title">Children Details</h5>
// //               <div className="table-responsive">
// //                 <table className="table table-hover">
// //                   <thead>
// //                     <tr>
// //                       <th>Child Name</th>
// //                       <th>Child ID</th>
// //                       <th>Child Age</th>
// //                       <th>Child Gender</th>
// //                       <th>Date of Birth</th>
// //                     </tr>
// //                   </thead>
// //                   <tbody>
// //                     {children.length > 0 ? (
// //                       children.map((child) => (
// //                         <tr key={child.childId || child.id}>
// //                           <td>{child.childName || 'N/A'}</td>
// //                           <td>{child.childId || child.id || 'N/A'}</td>
// //                           <td>{child.childAge || child.age || 'N/A'}</td>
// //                           <td>{child.childGender || child.gender || 'N/A'}</td>
// //                           <td>{child.dateOfBirth || 'N/A'}</td>
// //                         </tr>
// //                       ))
// //                     ) : (
// //                       <tr>
// //                         <td colSpan="5" className="text-center">No children found</td>
// //                       </tr>
// //                     )}
// //                   </tbody>
// //                 </table>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       case 'plans':
// //         return (
// //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// //             <div className="card-body">
// //               <h5 className="card-title">Insurance Plans</h5>
              
// //               <div className="mb-4">
// //                 <h6>Add New Plan</h6>
// //                 <form onSubmit={handleAddPlan}>
// //                   <div className="row">
// //                     <div className="col-md-4">
// //                       <div className="mb-3">
// //                         <label htmlFor="name" className="form-label">Plan Name</label>
// //                         <input
// //                           type="text"
// //                           className="form-control"
// //                           id="name"
// //                           value={newPlan.name}
// //                           onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
// //                           required
// //                         />
// //                       </div>
// //                     </div>
// //                     <div className="col-md-4">
// //                       <div className="mb-3">
// //                         <label htmlFor="monthlyPremium" className="form-label">Monthly Premium (₹)</label>
// //                         <input
// //                           type="number"
// //                           step="0.01"
// //                           className="form-control"
// //                           id="monthlyPremium"
// //                           value={newPlan.monthlyPremium}
// //                           onChange={(e) => setNewPlan({ ...newPlan, monthlyPremium: e.target.value })}
// //                           required
// //                         />
// //                       </div>
// //                     </div>
// //                     <div className="col-md-4">
// //                       <div className="mb-3">
// //                         <label htmlFor="coverageMonths" className="form-label">Coverage Months</label>
// //                         <input
// //                           type="number"
// //                           className="form-control"
// //                           id="coverageMonths"
// //                           value={newPlan.coverageMonths}
// //                           onChange={(e) => setNewPlan({ ...newPlan, coverageMonths: e.target.value })}
// //                           required
// //                         />
// //                       </div>
// //                     </div>
// //                   </div>
// //                   <button type="submit" className="btn btn-primary">Add Plan</button>
// //                 </form>
// //               </div>

// //               <h6 className="mt-4">Plans List</h6>
// //               <div className="table-responsive">
// //                 <table className="table table-hover">
// //                   <thead>
// //                     <tr>
// //                       <th>Plan ID</th>
// //                       <th>Plan Name</th>
// //                       <th>Monthly Premium (₹)</th>
// //                       <th>Coverage Months</th>
// //                       <th>Actions</th>
// //                     </tr>
// //                   </thead>
// //                   <tbody>
// //                     {plans.length > 0 ? (
// //                       plans.map((plan) => (
// //                         <tr key={plan.planId}>
// //                           <td>{plan.planId || 'N/A'}</td>
// //                           <td>{plan.name || 'N/A'}</td>
// //                           <td>₹{plan.monthlyPremium || '0.0'}</td>
// //                           <td>{plan.coverageMonths || '0'}</td>
// //                           <td>
// //                             <button
// //                               className="btn btn-danger btn-sm"
// //                               onClick={() => handleDeletePlan(plan)}
// //                             >
// //                               <FaTrash className="me-1" /> Delete
// //                             </button>
// //                           </td>
// //                         </tr>
// //                       ))
// //                     ) : (
// //                       <tr>
// //                         <td colSpan="5">No plans found.</td>
// //                       </tr>
// //                     )}
// //                   </tbody>
// //                 </table>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       case 'claims':
// //         return (
// //           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
// //             <div className="card-body">
// //               <h5 className="card-title">Pending Claims</h5>
// //               <div className="table-responsive">
// //                 <table className="table table-hover">
// //                   <thead>
// //                     <tr>
// //                       <th>Claim ID</th>
// //                       <th>Reason</th>
// //                       <th>Date</th>
// //                       <th>Status</th>
// //                     </tr>
// //                   </thead>
// //                   <tbody>
// //                     {claims.length > 0 ? (
// //                       claims.map((claim) => (
// //                         <tr key={claim.claimId}>
// //                           <td>{claim.claimId || 'N/A'}</td>
// //                           <td>{claim.reason || 'N/A'}</td>
// //                           <td>{claim.date || 'N/A'}</td>
// //                           <td>
// //                             <span className="badge bg-warning text-dark">{claim.status || 'Pending'}</span>
// //                           </td>
// //                         </tr>
// //                       ))
// //                     ) : (
// //                       <tr>
// //                         <td colSpan="4" className="text-center">No pending claims found.</td>
// //                       </tr>
// //                     )}
// //                   </tbody>
// //                 </table>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       default:
// //         return <div>Select a section from the sidebar</div>;
// //     }
// //   };

// //   return (
// //     <div className="container-fluid">
// //       <div className="row">
// //         {/* Sidebar */}
// //         <div className={`col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse ${sidebarCollapsed ? '' : 'show'}`}
// //              style={{ minHeight: '100vh', color: 'white' }}>
// //           <div className="position-sticky pt-3">
// //             <div className="d-flex justify-content-between align-items-center mb-3 px-3">
// //               <h4>Admin Panel</h4>
// //               <button 
// //                 className="btn btn-link text-white d-md-none" 
// //                 onClick={toggleSidebar}
// //               >
// //                 <FaBars />
// //               </button>
// //             </div>
// //             <ul className="nav flex-column">
// //               <li className="nav-item">
// //                 <button 
// //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'overview' ? 'active' : ''}`}
// //                   onClick={() => setActiveTab('overview')}
// //                 >
// //                   <FaHome className="me-2" /> Dashboard
// //                 </button>
// //               </li>
// //               <li className="nav-item">
// //                 <button 
// //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'parents' ? 'active' : ''}`}
// //                   onClick={() => setActiveTab('parents')}
// //                 >
// //                   <FaUsers className="me-2" /> Parents
// //                 </button>
// //               </li>
// //               <li className="nav-item">
// //                 <button 
// //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'children' ? 'active' : ''}`}
// //                   onClick={() => setActiveTab('children')}
// //                 >
// //                   <FaChild className="me-2" /> Children
// //                 </button>
// //               </li>
// //               <li className="nav-item">
// //                 <button 
// //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'plans' ? 'active' : ''}`}
// //                   onClick={() => setActiveTab('plans')}
// //                 >
// //                   <FaFileAlt className="me-2" /> Insurance Plans
// //                 </button>
// //               </li>
// //               <li className="nav-item">
// //                 <button 
// //                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'claims' ? 'active' : ''}`}
// //                   onClick={() => setActiveTab('claims')}
// //                 >
// //                   <FaFileContract className="me-2" /> Claims
// //                 </button>
// //               </li>
// //               <li className="nav-item mt-4">
// //                 <button 
// //                   className="nav-link btn btn-link text-danger text-start w-100"
// //                   onClick={handleLogout}
// //                 >
// //                   <FaSignOutAlt className="me-2" /> Logout
// //                 </button>
// //               </li>
// //             </ul>
// //           </div>
// //         </div>

// //         {/* Main content */}
// //         <main className="col-md-9 col-lg-10 px-md-4 py-4">
// //           <div className="d-flex justify-content-between align-items-center mb-4">
// //             <h2>
// //               {activeTab === 'overview' && 'Dashboard Overview'}
// //               {activeTab === 'parents' && 'Parent Management'}
// //               {activeTab === 'children' && 'Children Management'}
// //               {activeTab === 'plans' && 'Insurance Plans'}
// //               {activeTab === 'claims' && 'Claims Management'}
// //             </h2>
// //             <button 
// //               className="btn btn-outline-secondary d-md-none" 
// //               onClick={toggleSidebar}
// //             >
// //               <FaBars />
// //             </button>
// //           </div>

// //           {renderContent()}
// //         </main>
// //       </div>
// //     </div>
// //   );
// // };

// // export default AdminDashboard;

// ====================


// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { 
//   FaUsers, 
//   FaChild, 
//   FaFileContract, 
//   FaTrash, 
//   FaSignOutAlt,
//   FaFileAlt,
//   FaHome,
//   FaBars,
//   FaCheck,
//   FaTimes
// } from 'react-icons/fa';

// const AdminDashboard = () => {
//   const [activeTab, setActiveTab] = useState('overview');
//   const [plans, setPlans] = useState([]);
//   const [parents, setParents] = useState([]);
//   const [children, setChildren] = useState([]);
//   const [claims, setClaims] = useState([]);
//   const [newPlan, setNewPlan] = useState({
//     name: '',
//     monthlyPremium: '',
//     coverageMonths: ''
//   });
//   const [dashboardStats, setDashboardStats] = useState({
//     totalParents: 0,
//     totalChildren: 0,
//     totalPlans: 0,
//     pendingClaims: 0
//   });
//   const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const token = localStorage.getItem('adminToken');
//     const adminData = localStorage.getItem('adminData');
    
//     if (!token || !adminData) {
//       navigate('/');
//       return;
//     }
    
//     const fetchData = async () => {
//       await fetchParents();
//       await fetchChildren();
//       await fetchPlans();
//       await fetchPendingClaims();
//     };
//     fetchData();
//   }, [navigate]);

//   const fetchPlans = async () => {
//     try {
//       const response = await axios.get('http://localhost:9094/api/admin/getallplan');
//       setPlans(response.data);
//       updateDashboardStats('totalPlans', response.data.length);
//     } catch (error) {
//       console.error('Error fetching plans:', error);
//       alert('Failed to fetch plans');
//     }
//   };

//   const fetchParents = async () => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       const response = await axios.get('http://localhost:9094/api/admin/getAllParent', {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
      
//       if (response.data) {
//         const parentData = Array.isArray(response.data) ? response.data : [response.data];
//         setParents(parentData);
//         updateDashboardStats('totalParents', parentData.length);
//         console.log('Fetched parents:', parentData);
//       } else {
//         console.error('Invalid response format:', response.data);
//         alert('Received invalid data format from server');
//       }
//     } catch (error) {
//       console.error('Error fetching parents:', error);
//       if (error.response) {
//         alert(`Failed to fetch parents: ${error.response.data.message || 'Server error'}`);
//       } else {
//         alert('Failed to fetch parents. Please check your network connection.');
//       }
//     }
//   };

//   const fetchChildren = async () => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       const response = await axios.get('http://localhost:9094/api/admin/getAllChild', {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
      
//       if (response.data) {
//         const childData = Array.isArray(response.data) ? response.data : [response.data];
//         setChildren(childData);
//         updateDashboardStats('totalChildren', childData.length);
//         console.log('Fetched children:', childData);
//       } else {
//         console.error('Invalid response format:', response.data);
//         alert('Received invalid data format from server');
//       }
//     } catch (error) {
//       console.error('Error fetching children:', error);
//       if (error.response) {
//         alert(`Failed to fetch children: ${error.response.data.message || 'Server error'}`);
//       } else {
//         alert('Failed to fetch children. Please check your network connection.');
//       }
//     }
//   };

//   const fetchPendingClaims = async () => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       const response = await axios.get('http://localhost:9094/api/claims/pending', {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
//       const claimsData = Array.isArray(response.data) ? response.data : [response.data];
//       setClaims(claimsData);
//       updateDashboardStats('pendingClaims', claimsData.length);
//     } catch (error) {
//       console.error('Error fetching claims:', error);
//       alert('Failed to fetch claims: ' + (error.response?.data?.message || 'Server error'));
//     }
//   };

//   const handleAcceptClaim = async (claimId) => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       await axios.put(`http://localhost:9094/api/claims/${claimId}/accept`, {}, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
//       alert('Claim accepted successfully');
//       await fetchPendingClaims(); // Refresh claims list
//     } catch (error) {
//       console.error('Error accepting claim:', error);
//       alert('Failed to accept claim: ' + (error.response?.data?.message || 'Server error'));
//     }
//   };

//   const handleRejectClaim = async (claimId) => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       await axios.put(`http://localhost:9094/api/claims/${claimId}/reject`, {}, {
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json'
//         }
//       });
//       alert('Claim rejected successfully');
//       await fetchPendingClaims(); // Refresh claims list
//     } catch (error) {
//       console.error('Error rejecting claim:', error);
//       alert('Failed to reject claim: ' + (error.response?.data?.message || 'Server error'));
//     }
//   };

//   const updateDashboardStats = (key, value) => {
//     setDashboardStats(prev => ({
//       ...prev,
//       [key]: value
//     }));
//   };

//   const handleAddPlan = async (e) => {
//     e.preventDefault();
//     try {
//       const payload = {
//         name: newPlan.name,
//         monthlyPremium: parseFloat(newPlan.monthlyPremium),
//         coverageMonths: parseInt(newPlan.coverageMonths, 10)
//       };
//       await axios.post('http://localhost:9094/api/admin/addplan', payload);
//       alert('Plan added successfully');
//       setNewPlan({ name: '', monthlyPremium: '', coverageMonths: '' });
//       fetchPlans();
//     } catch (error) {
//       console.error('Error adding plan:', error);
//       alert('Failed to add plan: ' + (error.response?.data?.message || 'Server error'));
//     }
//   };

//   const handleDeletePlan = async (plan) => {
//     if (window.confirm('Are you sure you want to delete this plan?')) {
//       try {
//         await axios.post('http://localhost:9094/api/admin/delplan', plan);
//         alert('Plan deleted successfully');
//         fetchPlans();
//       } catch (error) {
//         console.error('Error deleting plan:', error);
//         alert('Failed to delete plan: ' + (error.response?.data?.message || 'Server error'));
//       }
//     }
//   };

//   const handleLogout = () => {
//     localStorage.removeItem('adminToken');
//     localStorage.removeItem('adminData');
//     navigate('/');
//   };

//   const toggleSidebar = () => {
//     setSidebarCollapsed(!sidebarCollapsed);
//   };

//   const renderContent = () => {
//     switch (activeTab) {
//       case 'overview':
//         return (
//           <div className="row g-4">
//             <div style={{ width: 'fit-content' }}>
//               <div className="card bg-primary text-white h-100">
//                 <div className="card-body">
//                   <div className="d-flex justify-content-between align-items-center">
//                     <div>
//                       <h6 className="card-title mb-3">Total Parents</h6>
//                       <h2 className="mb-0">{dashboardStats.totalParents}</h2>
//                     </div>
//                     <FaUsers size={24} />
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div style={{ width: 'fit-content' }}>
//               <div className="card bg-success text-white h-100">
//                 <div className="card-body">
//                   <div className="d-flex justify-content-between align-items-center">
//                     <div>
//                       <h6 className="card-title mb-3">Total Children</h6>
//                       <h2 className="mb-0">{dashboardStats.totalChildren}</h2>
//                     </div>
//                     <FaChild size={24} />
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div style={{ width: 'fit-content' }}>
//               <div className="card bg-info text-white h-100">
//                 <div className="card-body">
//                   <div className="d-flex justify-content-between align-items-center">
//                     <div>
//                       <h6 className="card-title mb-3">Total Plans</h6>
//                       <h2 className="mb-0">{dashboardStats.totalPlans}</h2>
//                     </div>
//                     <FaFileAlt size={24} />
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div style={{ width: 'fit-content' }}>
//               <div className="card bg-warning text-white h-100">
//                 <div className="card-body">
//                   <div className="d-flex justify-content-between align-items-center">
//                     <div>
//                       <h6 className="card-title mb-3">Pending Claims</h6>
//                       <h2 className="mb-0">{dashboardStats.pendingClaims}</h2>
//                     </div>
//                     <FaFileContract size={24} />
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         );
//       case 'parents':
//         return (
//           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
//             <div className="card-body">
//               <h5 className="card-title">Parent Details</h5>
//               <div className="table-responsive">
//                 <table className="table table-hover">
//                   <thead>
//                     <tr>
//                       <th>Parent Name</th>
//                       <th>Parent ID</th>
//                       <th>Parent Email</th>
//                       <th>Parent Number</th>
//                       <th>Children</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {parents.length > 0 ? (
//                       parents.map((parent) => (
//                         <tr key={parent.parentEmailId || parent.email}>
//                           <td>{parent.parentName}</td>
//                           <td>{parent.parentId || parent.parent_Id || 'N/A'}</td>
//                           <td>{parent.parentEmailId || parent.email}</td>
//                           <td>{parent.contactNumber || parent.phoneNumber || 'N/A'}</td>
//                           <td>
//                             {parent.children && parent.children.length > 0
//                               ? parent.children.map(child => child.childName).join(', ')
//                               : parent.childrenNames && parent.childrenNames.length > 0
//                               ? parent.childrenNames.join(', ')
//                               : 'No children'}
//                           </td>
//                         </tr>
//                       ))
//                     ) : (
//                       <tr>
//                         <td colSpan="5" className="text-center">No parents found</td>
//                       </tr>
//                     )}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         );
//       case 'children':
//         return (
//           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
//             <div className="card-body">
//               <h5 className="card-title">Children Details</h5>
//               <div className="table-responsive">
//                 <table className="table table-hover">
//                   <thead>
//                     <tr>
//                       <th>Child Name</th>
//                       <th>Child ID</th>
//                       <th>Child Age</th>
//                       <th>Child Gender</th>
//                       <th>Date of Birth</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {children.length > 0 ? (
//                       children.map((child) => (
//                         <tr key={child.childId || child.id}>
//                           <td>{child.childName || 'N/A'}</td>
//                           <td>{child.childId || child.id || 'N/A'}</td>
//                           <td>{child.childAge || child.age || 'N/A'}</td>
//                           <td>{child.childGender || child.gender || 'N/A'}</td>
//                           <td>{child.dateOfBirth || 'N/A'}</td>
//                         </tr>
//                       ))
//                     ) : (
//                       <tr>
//                         <td colSpan="5" className="text-center">No children found</td>
//                       </tr>
//                     )}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         );
//       case 'plans':
//         return (
//           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
//             <div className="card-body">
//               <h5 className="card-title">Insurance Plans</h5>
              
//               <div className="mb-4">
//                 <h6>Add New Plan</h6>
//                 <form onSubmit={handleAddPlan}>
//                   <div className="row">
//                     <div className="col-md-4">
//                       <div className="mb-3">
//                         <label htmlFor="name" className="form-label">Plan Name</label>
//                         <input
//                           type="text"
//                           className="form-control"
//                           id="name"
//                           value={newPlan.name}
//                           onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
//                           required
//                         />
//                       </div>
//                     </div>
//                     <div className="col-md-4">
//                       <div className="mb-3">
//                         <label htmlFor="monthlyPremium" className="form-label">Monthly Premium (₹)</label>
//                         <input
//                           type="number"
//                           step="0.01"
//                           className="form-control"
//                           id="monthlyPremium"
//                           value={newPlan.monthlyPremium}
//                           onChange={(e) => setNewPlan({ ...newPlan, monthlyPremium: e.target.value })}
//                           required
//                         />
//                       </div>
//                     </div>
//                     <div className="col-md-4">
//                       <div className="mb-3">
//                         <label htmlFor="coverageMonths" className="form-label">Coverage Months</label>
//                         <input
//                           type="number"
//                           className="form-control"
//                           id="coverageMonths"
//                           value={newPlan.coverageMonths}
//                           onChange={(e) => setNewPlan({ ...newPlan, coverageMonths: e.target.value })}
//                           required
//                         />
//                       </div>
//                     </div>
//                   </div>
//                   <button type="submit" className="btn btn-primary">Add Plan</button>
//                 </form>
//               </div>

//               <h6 className="mt-4">Plans List</h6>
//               <div className="table-responsive">
//                 <table className="table table-hover">
//                   <thead>
//                     <tr>
//                       <th>Plan ID</th>
//                       <th>Plan Name</th>
//                       <th>Monthly Premium (₹)</th>
//                       <th>Coverage Months</th>
//                       <th>Actions</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {plans.length > 0 ? (
//                       plans.map((plan) => (
//                         <tr key={plan.planId}>
//                           <td>{plan.planId || 'N/A'}</td>
//                           <td>{plan.name || 'N/A'}</td>
//                           <td>₹{plan.monthlyPremium || '0.0'}</td>
//                           <td>{plan.coverageMonths || '0'}</td>
//                           <td>
//                             <button
//                               className="btn btn-danger btn-sm"
//                               onClick={() => handleDeletePlan(plan)}
//                             >
//                               <FaTrash className="me-1" /> Delete
//                             </button>
//                           </td>
//                         </tr>
//                       ))
//                     ) : (
//                       <tr>
//                         <td colSpan="5">No plans found.</td>
//                       </tr>
//                     )}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         );
//       case 'claims':
//         return (
//           <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
//             <div className="card-body">
//               <h5 className="card-title">Pending Claims</h5>
//               <div className="table-responsive">
//                 <table className="table table-hover">
//                   <thead>
//                     <tr>
//                       <th>Claim ID</th>
//                       <th>Reason</th>
//                       <th>Date</th>
//                       <th>Status</th>
//                       <th>Actions</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {claims.length > 0 ? (
//                       claims.map((claim) => (
//                         <tr key={claim.claimId}>
//                           <td>{claim.claimId || 'N/A'}</td>
//                           <td>{claim.reason || 'N/A'}</td>
//                           <td>{claim.date || 'N/A'}</td>
//                           <td>
//                             <span className={`badge ${claim.status === 'Accepted' ? 'bg-success' : claim.status === 'Rejected' ? 'bg-danger' : 'bg-warning'} text-white`}>
//                               {claim.status || 'Pending'}
//                             </span>
//                           </td>
//                           <td>
//                             {claim.status === 'Pending' && (
//                               <div className="d-flex gap-2">
//                                 <button
//                                   className="btn btn-success btn-sm"
//                                   onClick={() => handleAcceptClaim(claim.claimId)}
//                                 >
//                                   <FaCheck className="me-1" /> Accept
//                                 </button>
//                                 <button
//                                   className="btn btn-danger btn-sm"
//                                   onClick={() => handleRejectClaim(claim.claimId)}
//                                 >
//                                   <FaTimes className="me-1" /> Reject
//                                 </button>
//                               </div>
//                             )}
//                           </td>
//                         </tr>
//                       ))
//                     ) : (
//                       <tr>
//                         <td colSpan="5" className="text-center">No pending claims found.</td>
//                       </tr>
//                     )}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         );
//       default:
//         return <div>Select a section from the sidebar</div>;
//     }
//   };

//   return (
//     <div className="container-fluid">
//       <div className="row">
//         {/* Sidebar */}
//         <div className={`col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse ${sidebarCollapsed ? '' : 'show'}`}
//              style={{ minHeight: '100vh', color: 'white' }}>
//           <div className="position-sticky pt-3">
//             <div className="d-flex justify-content-between align-items-center mb-3 px-3">
//               <h4>Admin Panel</h4>
//               <button 
//                 className="btn btn-link text-white d-md-none" 
//                 onClick={toggleSidebar}
//               >
//                 <FaBars />
//               </button>
//             </div>
//             <ul className="nav flex-column">
//               <li className="nav-item">
//                 <button 
//                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'overview' ? 'active' : ''}`}
//                   onClick={() => setActiveTab('overview')}
//                 >
//                   <FaHome className="me-2" /> Dashboard
//                 </button>
//               </li>
//               <li className="nav-item">
//                 <button 
//                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'parents' ? 'active' : ''}`}
//                   onClick={() => setActiveTab('parents')}
//                 >
//                   <FaUsers className="me-2" /> Parents
//                 </button>
//               </li>
//               <li className="nav-item">
//                 <button 
//                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'children' ? 'active' : ''}`}
//                   onClick={() => setActiveTab('children')}
//                 >
//                   <FaChild className="me-2" /> Children
//                 </button>
//               </li>
//               <li className="nav-item">
//                 <button 
//                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'plans' ? 'active' : ''}`}
//                   onClick={() => setActiveTab('plans')}
//                 >
//                   <FaFileAlt className="me-2" /> Insurance Plans
//                 </button>
//               </li>
//               <li className="nav-item">
//                 <button 
//                   className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'claims' ? 'active' : ''}`}
//                   onClick={() => setActiveTab('claims')}
//                 >
//                   <FaFileContract className="me-2" /> Claims
//                 </button>
//               </li>
//               <li className="nav-item mt-4">
//                 <button 
//                   className="nav-link btn btn-link text-danger text-start w-100"
//                   onClick={handleLogout}
//                 >
//                   <FaSignOutAlt className="me-2" /> Logout
//                 </button>
//               </li>
//             </ul>
//           </div>
//         </div>

//         {/* Main content */}
//         <main className="col-md-9 col-lg-10 px-md-4 py-4">
//           <div className="d-flex justify-content-between align-items-center mb-4">
//             <h2>
//               {activeTab === 'overview' && 'Dashboard Overview'}
//               {activeTab === 'parents' && 'Parent Management'}
//               {activeTab === 'children' && 'Children Management'}
//               {activeTab === 'plans' && 'Insurance Plans'}
//               {activeTab === 'claims' && 'Claims Management'}
//             </h2>
//             <button 
//               className="btn btn-outline-secondary d-md-none" 
//               onClick={toggleSidebar}
//             >
//               <FaBars />
//             </button>
//           </div>

//           {renderContent()}
//         </main>
//       </div>
//     </div>
//   );
// };

// export default AdminDashboard;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { 
  FaUsers, 
  FaChild, 
  FaFileContract, 
  FaTrash, 
  FaSignOutAlt,
  FaFileAlt,
  FaHome,
  FaBars,
  FaCheck,
  FaTimes
} from 'react-icons/fa';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [plans, setPlans] = useState([]);
  const [parents, setParents] = useState([]);
  const [children, setChildren] = useState([]);
  const [claims, setClaims] = useState([]);
  const [newPlan, setNewPlan] = useState({
    name: '',
    monthlyPremium: '',
    coverageMonths: ''
  });
  const [dashboardStats, setDashboardStats] = useState({
    totalParents: 0,
    totalChildren: 0,
    totalPlans: 0,
    pendingClaims: 0
  });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    const adminData = localStorage.getItem('adminData');
    
    if (!token || !adminData) {
      navigate('/');
      return;
    }
    
    const fetchData = async () => {
      await fetchParents();
      await fetchChildren();
      await fetchPlans();
      await fetchPendingClaims();
    };
    fetchData();
  }, [navigate]);

  const fetchPlans = async () => {
    try {
      const response = await axios.get('http://localhost:9094/api/admin/getallplan');
      setPlans(response.data);
      updateDashboardStats('totalPlans', response.data.length);
    } catch (error) {
      console.error('Error fetching plans:', error);
      alert('Failed to fetch plans');
    }
  };

  const fetchParents = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const response = await axios.get('http://localhost:9094/api/admin/getAllParent', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.data) {
        const parentData = Array.isArray(response.data) ? response.data : [response.data];
        setParents(parentData);
        updateDashboardStats('totalParents', parentData.length);
        console.log('Fetched parents:', parentData);
      } else {
        console.error('Invalid response format:', response.data);
        alert('Received invalid data format from server');
      }
    } catch (error) {
      console.error('Error fetching parents:', error);
      if (error.response) {
        alert(`Failed to fetch parents: ${error.response.data.message || 'Server error'}`);
      } else {
        alert('Failed to fetch parents. Please check your network connection.');
      }
    }
  };

  const fetchChildren = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const response = await axios.get('http://localhost:9094/api/admin/getAllChild', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.data) {
        const childData = Array.isArray(response.data) ? response.data : [response.data];
        setChildren(childData);
        updateDashboardStats('totalChildren', childData.length);
        console.log('Fetched children:', childData);
      } else {
        console.error('Invalid response format:', response.data);
        alert('Received invalid data format from server');
      }
    } catch (error) {
      console.error('Error fetching children:', error);
      if (error.response) {
        alert(`Failed to fetch children: ${error.response.data.message || 'Server error'}`);
      } else {
        alert('Failed to fetch children. Please check your network connection.');
      }
    }
  };

  const fetchPendingClaims = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const response = await axios.get('http://localhost:9094/api/claims/pending', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      const claimsData = Array.isArray(response.data) ? response.data : [response.data];
      setClaims(claimsData);
      updateDashboardStats('pendingClaims', claimsData.length);
    } catch (error) {
      console.error('Error fetching claims:', error);
      alert('Failed to fetch claims: ' + (error.response?.data?.message || 'Server error'));
    }
  };

  const handleAcceptClaim = async (claimId) => {
    try {
      const token = localStorage.getItem('adminToken');
      await axios.put(`http://localhost:9094/api/claims/approve/${claimId}`, {}, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      alert('Claim accepted successfully');
      await fetchPendingClaims(); // Refresh claims list
    } catch (error) {
      console.error('Error accepting claim:', error);
      alert('Failed to accept claim: ' + (error.response?.data?.message || 'Server error'));
    }
  };

  const handleRejectClaim = async (claimId) => {
    try {
      const token = localStorage.getItem('adminToken');
      await axios.put(`http://localhost:9094/api/claims/reject/${claimId}`, {}, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      alert('Claim rejected successfully');
      await fetchPendingClaims(); // Refresh claims list
    } catch (error) {
      console.error('Error rejecting claim:', error);
      alert('Failed to reject claim: ' + (error.response?.data?.message || 'Server error'));
    }
  };

  const updateDashboardStats = (key, value) => {
    setDashboardStats(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleAddPlan = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        name: newPlan.name,
        monthlyPremium: parseFloat(newPlan.monthlyPremium),
        coverageMonths: parseInt(newPlan.coverageMonths, 10)
      };
      await axios.post('http://localhost:9094/api/admin/addplan', payload);
      alert('Plan added successfully');
      setNewPlan({ name: '', monthlyPremium: '', coverageMonths: '' });
      fetchPlans();
    } catch (error) {
      console.error('Error adding plan:', error);
      alert('Failed to add plan: ' + (error.response?.data?.message || 'Server error'));
    }
  };

  const handleDeletePlan = async (plan) => {
    if (window.confirm('Are you sure you want to delete this plan?')) {
      try {
        await axios.post('http://localhost:9094/api/admin/delplan', plan);
        alert('Plan deleted successfully');
        fetchPlans();
      } catch (error) {
        console.error('Error deleting plan:', error);
        alert('Failed to delete plan: ' + (error.response?.data?.message || 'Server error'));
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminData');
    navigate('/');
  };

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="row g-4">
            <div style={{ width: 'fit-content' }}>
              <div className="card bg-primary text-white h-100">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-3">Total Parents</h6>
                      <h2 className="mb-0">{dashboardStats.totalParents}</h2>
                    </div>
                    <FaUsers size={24} />
                  </div>
                </div>
              </div>
            </div>
            <div style={{ width: 'fit-content' }}>
              <div className="card bg-success text-white h-100">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-3">Total Children</h6>
                      <h2 className="mb-0">{dashboardStats.totalChildren}</h2>
                    </div>
                    <FaChild size={24} />
                  </div>
                </div>
              </div>
            </div>
            <div style={{ width: 'fit-content' }}>
              <div className="card bg-info text-white h-100">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-3">Total Plans</h6>
                      <h2 className="mb-0">{dashboardStats.totalPlans}</h2>
                    </div>
                    <FaFileAlt size={24} />
                  </div>
                </div>
              </div>
            </div>
            <div style={{ width: 'fit-content' }}>
              <div className="card bg-warning text-white h-100">
                <div className="card-body">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="card-title mb-3">Pending Claims</h6>
                      <h2 className="mb-0">{dashboardStats.pendingClaims}</h2>
                    </div>
                    <FaFileContract size={24} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'parents':
        return (
          <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
            <div className="card-body">
              <h5 className="card-title">Parent Details</h5>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Parent Name</th>
                      <th>Parent ID</th>
                      <th>Parent Email</th>
                      <th>Parent Number</th>
                      <th>Children</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parents.length > 0 ? (
                      parents.map((parent) => (
                        <tr key={parent.parentEmailId || parent.email}>
                          <td>{parent.parentName}</td>
                          <td>{parent.parentId || parent.parent_Id || 'N/A'}</td>
                          <td>{parent.parentEmailId || parent.email}</td>
                          <td>{parent.contactNumber || parent.phoneNumber || 'N/A'}</td>
                          <td>
                            {parent.children && parent.children.length > 0
                              ? parent.children.map(child => child.childName).join(', ')
                              : parent.childrenNames && parent.childrenNames.length > 0
                              ? parent.childrenNames.join(', ')
                              : 'No children'}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5" className="text-center">No parents found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      case 'children':
        return (
          <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
            <div className="card-body">
              <h5 className="card-title">Children Details</h5>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Child Name</th>
                      <th>Child ID</th>
                      <th>Child Age</th>
                      <th>Child Gender</th>
                      <th>Date of Birth</th>
                    </tr>
                  </thead>
                  <tbody>
                    {children.length > 0 ? (
                      children.map((child) => (
                        <tr key={child.childId || child.id}>
                          <td>{child.childName || 'N/A'}</td>
                          <td>{child.childId || child.id || 'N/A'}</td>
                          <td>{child.childAge || child.age || 'N/A'}</td>
                          <td>{child.childGender || child.gender || 'N/A'}</td>
                          <td>{child.dateOfBirth || 'N/A'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5" className="text-center">No children found</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      case 'plans':
        return (
          <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
            <div className="card-body">
              <h5 className="card-title">Insurance Plans</h5>
              
              <div className="mb-4">
                <h6>Add New Plan</h6>
                <form onSubmit={handleAddPlan}>
                  <div className="row">
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label htmlFor="name" className="form-label">Plan Name</label>
                        <input
                          type="text"
                          className="form-control"
                          id="name"
                          value={newPlan.name}
                          onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label htmlFor="monthlyPremium" className="form-label">Monthly Premium (₹)</label>
                        <input
                          type="number"
                          step="0.01"
                          className="form-control"
                          id="monthlyPremium"
                          value={newPlan.monthlyPremium}
                          onChange={(e) => setNewPlan({ ...newPlan, monthlyPremium: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="mb-3">
                        <label htmlFor="coverageMonths" className="form-label">Coverage Months</label>
                        <input
                          type="number"
                          className="form-control"
                          id="coverageMonths"
                          value={newPlan.coverageMonths}
                          onChange={(e) => setNewPlan({ ...newPlan, coverageMonths: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                  </div>
                  <button type="submit" className="btn btn-primary">Add Plan</button>
                </form>
              </div>

              <h6 className="mt-4">Plans List</h6>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Plan ID</th>
                      <th>Plan Name</th>
                      <th>Monthly Premium (₹)</th>
                      <th>Coverage Months</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {plans.length > 0 ? (
                      plans.map((plan) => (
                        <tr key={plan.planId}>
                          <td>{plan.planId || 'N/A'}</td>
                          <td>{plan.name || 'N/A'}</td>
                          <td>₹{plan.monthlyPremium || '0.0'}</td>
                          <td>{plan.coverageMonths || '0'}</td>
                          <td>
                            <button
                              className="btn btn-danger btn-sm"
                              onClick={() => handleDeletePlan(plan)}
                            >
                              <FaTrash className="me-1" /> Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5">No plans found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      case 'claims':
        return (
          <div className="card" style={{ width: '100%', maxWidth: 'none' }}>
            <div className="card-body">
              <h5 className="card-title">Pending Claims</h5>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Claim ID</th>
                      <th>Reason</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {claims.length > 0 ? (
                      claims.map((claim) => (
                        <tr key={claim.claimId}>
                          <td>{claim.claimId || 'N/A'}</td>
                          <td>{claim.reason || 'N/A'}</td>
                          <td>{claim.date || 'N/A'}</td>
                          <td>
                            <span className={`badge ${claim.status === 'Accepted' ? 'bg-success' : claim.status === 'Rejected' ? 'bg-danger' : 'bg-warning'} text-white`}>
                              {claim.status || 'Pending'}
                            </span>
                          </td>
                          <td>
                            {claim.status === 'Pending' && (
                              <div className="d-flex gap-2">
                                <button
                                  className="btn btn-success btn-sm"
                                  onClick={() => handleAcceptClaim(claim.claimId)}
                                >
                                  <FaCheck className="me-1" /> Accept
                                </button>
                                <button
                                  className="btn btn-danger btn-sm"
                                  onClick={() => handleRejectClaim(claim.claimId)}
                                >
                                  <FaTimes className="me-1" /> Reject
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5" className="text-center">No pending claims found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      default:
        return <div>Select a section from the sidebar</div>;
    }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <div className={`col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse ${sidebarCollapsed ? '' : 'show'}`}
             style={{ minHeight: '100vh', color: 'white' }}>
          <div className="position-sticky pt-3">
            <div className="d-flex justify-content-between align-items-center mb-3 px-3">
              <h4>Admin Panel</h4>
              <button 
                className="btn btn-link text-white d-md-none" 
                onClick={toggleSidebar}
              >
                <FaBars />
              </button>
            </div>
            <ul className="nav flex-column">
              <li className="nav-item">
                <button 
                  className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'overview' ? 'active' : ''}`}
                  onClick={() => setActiveTab('overview')}
                >
                  <FaHome className="me-2" /> Dashboard
                </button>
              </li>
              <li className="nav-item">
                <button 
                  className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'parents' ? 'active' : ''}`}
                  onClick={() => setActiveTab('parents')}
                >
                  <FaUsers className="me-2" /> Parents
                </button>
              </li>
              <li className="nav-item">
                <button 
                  className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'children' ? 'active' : ''}`}
                  onClick={() => setActiveTab('children')}
                >
                  <FaChild className="me-2" /> Children
                </button>
              </li>
              <li className="nav-item">
                <button 
                  className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'plans' ? 'active' : ''}`}
                  onClick={() => setActiveTab('plans')}
                >
                  <FaFileAlt className="me-2" /> Insurance Plans
                </button>
              </li>
              <li className="nav-item">
                <button 
                  className={`nav-link btn btn-link text-white text-start w-100 ${activeTab === 'claims' ? 'active' : ''}`}
                  onClick={() => setActiveTab('claims')}
                >
                  <FaFileContract className="me-2" /> Claims
                </button>
              </li>
              <li className="nav-item mt-4">
                <button 
                  className="nav-link btn btn-link text-danger text-start w-100"
                  onClick={handleLogout}
                >
                  <FaSignOutAlt className="me-2" /> Logout
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Main content */}
        <main className="col-md-9 col-lg-10 px-md-4 py-4">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2>
              {activeTab === 'overview' && 'Dashboard Overview'}
              {activeTab === 'parents' && 'Parent Management'}
              {activeTab === 'children' && 'Children Management'}
              {activeTab === 'plans' && 'Insurance Plans'}
              {activeTab === 'claims' && 'Claims Management'}
            </h2>
            <button 
              className="btn btn-outline-secondary d-md-none" 
              onClick={toggleSidebar}
            >
              <FaBars />
            </button>
          </div>

          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;