import React, { useState } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './AllContact.css';

const Allcontact = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would typically send the data to your backend
    console.log('Form submitted:', formData);
    toast.success('Message sent successfully!');
    setFormData({
      fullName: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  return (
    <div className="contact-container min-vh-100">
      <ToastContainer />
      <div className="container py-5">
        <div className="row">
          {/* Left Sidebar */}
          <div className="col-lg-5">
            <div className="contact-info h-100 p-4 rounded-lg">
              <h2 className="text-white mb-4">Get in Touch</h2>
              <p className="text-white-50 mb-5">
                We're here to help and answer any questions you might have about our child insurance plans.
                We look forward to hearing from you.
              </p>

              <div className="contact-details">
                <div className="info-card mb-4">
                  <h5 className="text-white">📍 Address</h5>
                  <p className="text-white-50">
                    123 Insurance Plaza<br />
                    New Delhi, India 110001
                  </p>
                </div>

                <div className="info-card mb-4">
                  <h5 className="text-white">📞 Phone</h5>
                  <p className="text-white-50">
                    +91 123-456-7890<br />
                    +91 098-765-4321
                  </p>
                </div>

                <div className="info-card mb-4">
                  <h5 className="text-white">✉️ Email</h5>
                  <p className="text-white-50">
                    support@childinsurance.com<br />
                    info@childinsurance.com
                  </p>
                </div>

                <div className="info-card">
                  <h5 className="text-white">⏰ Business Hours</h5>
                  <p className="text-white-50">
                    Monday - Friday: 9:00 AM - 6:00 PM<br />
                    Saturday: 9:00 AM - 1:00 PM
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side Contact Form */}
          <div className="col-lg-7">
            <div className="contact-form bg-white p-4 rounded-lg">
              <h3 className="mb-4">Send us a Message</h3>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Full Name"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Email Address"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <textarea
                    className="form-control"
                    rows="5"
                    placeholder="Your Message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-primary w-100">
                  Send Message
                </button>
              </form>

              {/* FAQ Section */}
              <div className="mt-5">
                <h4 className="mb-4">Frequently Asked Questions</h4>
                <div className="accordion" id="faqAccordion">
                  {[
                    {
                      question: 'How do I file a claim?',
                      answer: 'You can file a claim through your parent dashboard or by contacting our support team.'
                    },
                    {
                      question: 'What documents are needed for registration?',
                      answer: 'You\'ll need your child\'s birth certificate, your ID proof, and address proof.'
                    },
                    {
                      question: 'How long does claim processing take?',
                      answer: 'Most claims are processed within 7-10 business days after submission.'
                    }
                  ].map((faq, index) => (
                    <div className="card faq-card mb-2" key={index}>
                      <div className="card-header" id={`heading${index}`}>
                        <h2 className="mb-0">
                          <button
                            className="btn btn-link btn-block text-left collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target={`#collapse${index}`}
                          >
                            {faq.question}
                          </button>
                        </h2>
                      </div>
                      <div
                        id={`collapse${index}`}
                        className="collapse"
                        data-bs-parent="#faqAccordion"
                      >
                        <div className="card-body">
                          {faq.answer}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Allcontact; 