import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import {
  FaUser,
  FaChild,
  FaPlus,
  FaBell,
  FaSignOutAlt,
  FaHome,
  FaFileAlt,
  FaMoneyBill,
  FaClipboardList,
  FaTachometerAlt
} from "react-icons/fa";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ParentDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [showAddChildModal, setShowAddChildModal] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [newChild, setNewChild] = useState({
    childName: "",
    childGender: "",
    childAge: "",
    dateOfBirth: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    const userEmail = localStorage.getItem("userEmail");
    const userDetails = localStorage.getItem("userDetails");

    if (!userEmail || !userDetails) {
      navigate("/");
      return;
    }

    try {
      const parsedData = JSON.parse(userDetails);
      // Use dashboard property if present
      const dashboard = parsedData.dashboard || parsedData;
      console.log("Parsed dashboard data:", dashboard);

      // Initialize children array from either children or childrenNames
      const childrenArray = dashboard.children || dashboard.childrenNames || [];
      console.log("Children data:", childrenArray);

      setDashboardData({
        parentName: dashboard.parentName || "Parent",
        email: userEmail,
        childrenNames: childrenArray,
        policies: dashboard.Plan || [],
        claimCount: dashboard.claimCount || 0,
        transactionCount: dashboard.transactionCount || 0,
      });

      // Also update localStorage with the latest structure
      localStorage.setItem("userDetails", JSON.stringify({
        ...dashboard,
        childrenNames: childrenArray
      }));
    } catch (error) {
      console.error("Error parsing user details:", error);
      navigate("/");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewChild((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateDateOfBirth = (dob) => {
    const dobDate = new Date(dob);
    const today = new Date();
    const age = today.getFullYear() - dobDate.getFullYear();
    const monthDiff = today.getMonth() - dobDate.getMonth();
    
    if (dobDate > today) {
      return "Date of birth cannot be in the future";
    }
    
    if (age > 18 || (age === 18 && monthDiff >= 0)) {
      return "Child must be under 18 years old";
    }
    
    return null;
  };

  const handleAddChild = async (e) => {
    e.preventDefault();

    // Validate form
    if (!newChild.childName || !newChild.childGender || !newChild.childAge || !newChild.dateOfBirth) {
      toast.error("Please fill in all fields");
      return;
    }

    // Validate child name
    if (newChild.childName.length < 2) {
      toast.error("Child name must be at least 2 characters long");
      return;
    }

    // Validate age
    const age = parseInt(newChild.childAge);
    if (isNaN(age) || age < 0 || age > 18) {
      toast.error("Age must be between 0 and 18");
      return;
    }

    // Validate date of birth
    const dobError = validateDateOfBirth(newChild.dateOfBirth);
    if (dobError) {
      toast.error(dobError);
      return;
    }

    setIsLoading(true);

    try {
      const userEmail = localStorage.getItem("userEmail");
      const response = await fetch(
        `http://localhost:9094/api/child/add?parentEmailId=${encodeURIComponent(userEmail)}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            childName: newChild.childName,
            childGender: newChild.childGender,
            childAge: parseInt(newChild.childAge),
            dateOfBirth: newChild.dateOfBirth,
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        toast.success("Child added successfully!");
        setShowAddChildModal(false);

        // Update the dashboard data
        const updatedChildrenNames = [...(dashboardData.childrenNames || []), newChild.childName];
        
        setDashboardData((prev) => ({
          ...prev,
          childrenNames: updatedChildrenNames,
        }));

        // Update localStorage with new child data
        const userDetails = JSON.parse(localStorage.getItem("userDetails"));
        localStorage.setItem("userDetails", JSON.stringify({
          ...userDetails,
          childrenNames: updatedChildrenNames
        }));

        // Reset form
        setNewChild({
          childName: "",
          childGender: "",
          childAge: "",
          dateOfBirth: "",
        });
      } else {
        const errorData = await response.text();
        console.error("Server response:", errorData);
        toast.error("Failed to add child. Please try again.");
      }
    } catch (error) {
      console.error("Error adding child:", error);
      toast.error("An error occurred while adding the child. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (!dashboardData) {
    return (
      <div className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  const { parentName, email, childrenNames } = dashboardData;

  return (
    <div className="d-flex">
      {/* Sidebar */}
      <div className={`bg-dark text-white ${sidebarCollapsed ? 'w-auto' : 'w-280px'}`} 
           style={{ minHeight: "100vh", transition: "all 0.3s", display: "flex", flexDirection: "column" }}>
        <div className="p-3 flex-grow-1">
          <div className="d-flex align-items-center mb-4 justify-content-between">
            {!sidebarCollapsed && (
              <span className="fs-4 fw-bold">Child Insurance</span>
            )}
            <button
              className="btn btn-link text-white p-0" 
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            >
              <FaChild size={24} />
            </button>
          </div>
          
          <div className="nav flex-column gap-2">
            <Link to="/parent-dashboard" className="nav-link text-white active d-flex align-items-center gap-2">
              <FaTachometerAlt size={18} />
              {!sidebarCollapsed && <span>Dashboard</span>}
            </Link>
            <Link to="/policy-form" className="nav-link text-white d-flex align-items-center gap-2">
              <FaFileAlt size={18} />
              {!sidebarCollapsed && <span>Buy Policy</span>}
            </Link>
            <Link to="/Buypolicy" className="nav-link text-white d-flex align-items-center gap-2">
              <FaMoneyBill size={18} />
              {!sidebarCollapsed && <span>Pay Premium</span>}
            </Link>
            <Link to="/Detail-policy" className="nav-link text-white d-flex align-items-center gap-2">
              <FaClipboardList size={18} />
              {!sidebarCollapsed && <span>My Policies</span>}
            </Link>
            <Link to="/Claim-form" className="nav-link text-white d-flex align-items-center gap-2">
              <FaFileAlt size={18} />
              {!sidebarCollapsed && <span>File Claim</span>}
            </Link>
          </div>
        </div>
        
        {/* Logout Button at Bottom */}
        <div className="p-3 border-top border-secondary">
          <button
            className="btn btn-outline-light w-100 d-flex align-items-center gap-2 justify-content-center py-2"
            onClick={handleLogout}
          >
            <FaSignOutAlt size={18} />
            {!sidebarCollapsed && <span>Logout</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 bg-light">
        {/* Top Navigation */}
        <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top py-3">
          <div className="container-fluid px-4">
            <div className="d-flex align-items-center">
              <h4 className="mb-0 fw-bold text-primary">Welcome, {parentName}!</h4>
              <span className="ms-2 text-muted">({email})</span>
    </div>
            <div className="d-flex align-items-center gap-4">
              <div className="position-relative">
                <FaBell className="text-muted" style={{ fontSize: "1.4rem" }} />
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  2
                </span>
  </div>
              <div className="vr"></div>
              <div className="d-flex align-items-center gap-3">
                <div className="bg-primary bg-opacity-10 rounded-circle p-2">
                  <FaUser className="text-primary" size={20} />
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Dashboard Content */}
        <div className="container" style={{ marginTop: "2rem", maxWidth: "1200px" }}>
          {/* Welcome Message */}
          <div className="d-flex align-items-baseline mb-5">
            <h2 className="text-primary mb-0">Welcome, {parentName}!</h2>
            <span className="ms-3 text-muted">{email}</span>
            </div>
          
          {/* Quick Actions and Children List side by side */}
          <div className="row g-4 justify-content-center" style={{ marginTop: "2rem" }}>
            {/* Quick Actions */}
            <div className="col-md-5">
              <div className="card border-0 shadow-sm hover-shadow h-100" style={{ 
                transition: "all 0.3s",
                backgroundColor: "#ffffff",
                borderRadius: "12px",
                marginBottom: "2rem"
              }}>
                <div className="card-header bg-white border-0 py-4">
                  <div className="d-flex align-items-center">
                    <FaUser className="text-primary me-2" size={20} />
                    <h5 className="card-title mb-0">Quick Actions</h5>
                  </div>
                </div>
                <div className="card-body px-4 pb-4">
                  <div className="d-flex flex-column gap-4">
                    <button
                      className="btn btn-primary px-4 py-3 d-flex align-items-center justify-content-center"
                      onClick={() => navigate("/edit-parent-email")}
                      style={{ marginBottom: "1rem" }}
                    >
                      <FaUser className="me-2" /> Update Email
                    </button>
                    <button
                      className="btn btn-outline-primary px-4 py-3 d-flex align-items-center justify-content-center"
                      onClick={() => navigate("/Allcontact")}
                    >
                      <FaBell className="me-2" /> Contact Support
                    </button>
                  </div>
                </div>
              </div>
        </div>

          {/* Children List */}
            <div className="col-md-7">
              <div className="card border-0 shadow-sm hover-shadow h-100" style={{ 
                transition: "all 0.3s",
                backgroundColor: "#ffffff",
                borderRadius: "12px",
                marginBottom: "2rem"
              }}>
                <div className="card-header bg-white border-0 py-4">
                <div className="d-flex align-items-center justify-content-between">
                  <div className="d-flex align-items-center">
                    <FaChild className="text-primary me-2" size={20} />
                    <h5 className="card-title mb-0">My Children</h5>
                  </div>
                  <button
                      className="btn btn-primary d-flex align-items-center gap-2 px-4 py-2"
                    onClick={() => setShowAddChildModal(true)}
                  >
                      <FaPlus /> Add Child
                  </button>
                </div>
              </div>
                <div className="card-body px-4">
                {Array.isArray(childrenNames) && childrenNames.length > 0 ? (
                  <div className="list-group list-group-flush">
                    {childrenNames.map((child, index) => (
                        <div key={index} className="list-group-item border-0 py-3">
                        <div className="d-flex align-items-center">
                          <div className="bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                            <FaChild className="text-primary" />
                          </div>
                          <div>
                            <h6 className="mb-0">{child}</h6>
                              <small className="text-muted">Child {index + 1}</small>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-5">
                    <FaChild className="text-muted mb-3" size={48} />
                    <p className="text-muted mb-0">No children registered</p>
                  </div>
                )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Child Modal */}
      {showAddChildModal && (
        <div
          className="modal show d-block"
          style={{ backgroundColor: "rgba(0,0,0,0.5)", position: "fixed", top: 0, left: 0, right: 0, bottom: 0, zIndex: 1050 }}
          tabIndex="-1"
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Child</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => {
                    setShowAddChildModal(false);
                    setNewChild({
                      childName: "",
                      childGender: "",
                      childAge: "",
                      dateOfBirth: "",
                    });
                  }}
                ></button>
              </div>
              <form onSubmit={handleAddChild}>
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label">Child's Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="childName"
                      value={newChild.childName}
                      onChange={handleInputChange}
                      placeholder="Enter child's name"
                      required
                      minLength="2"
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Gender</label>
                    <select
                      className="form-select"
                      name="childGender"
                      value={newChild.childGender}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Age</label>
                    <input
                      type="number"
                      className="form-control"
                      name="childAge"
                      value={newChild.childAge}
                      onChange={handleInputChange}
                      placeholder="Enter age"
                      min="0"
                      max="18"
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Date of Birth</label>
                    <input
                      type="date"
                      className="form-control"
                      name="dateOfBirth"
                      value={newChild.dateOfBirth}
                      onChange={handleInputChange}
                      max={new Date().toISOString().split('T')[0]}
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setShowAddChildModal(false);
                      setNewChild({
                        childName: "",
                        childGender: "",
                        childAge: "",
                        dateOfBirth: "",
                      });
                    }}
                    disabled={isLoading}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Adding...
                      </>
                    ) : (
                      'Add Child'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <ToastContainer position="top-right" />
    </div>
  );
};

export default ParentDashboard;
