import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaUser, FaEnvelope, FaArrowLeft, FaBell, FaSignOutAlt } from 'react-icons/fa';

const ParentEmailEdit = () => {
  const navigate = useNavigate();
  const [parentData, setParentData] = useState(null);
  const [newEmail, setNewEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const userDetails = localStorage.getItem('userDetails');
    const userEmail = localStorage.getItem('userEmail');
    
    if (!userDetails || !userEmail) {
      navigate('/login');
      return;
    }

    try {
      const parsed = JSON.parse(userDetails);
      const dashboard = parsed.dashboard || parsed;
      setParentData({
        parentName: dashboard.parentName,
        email: userEmail
      });
    } catch (error) {
      console.error('Error parsing user details:', error);
      navigate('/login');
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:9094/api/user/updateemail', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          oldEmail: parentData.email,
          newEmail: newEmail
        }),
      });

      const data = await response.text();

      if (response.ok) {
        setParentData(prev => ({
          ...prev,
          email: newEmail
        }));

        const userDetails = JSON.parse(localStorage.getItem('userDetails'));
        const dashboard = userDetails.dashboard || userDetails;
        dashboard.email = newEmail;
        localStorage.setItem('userDetails', JSON.stringify(userDetails));
        localStorage.setItem('userEmail', newEmail);

        toast.success('Email updated successfully!');
        setNewEmail('');
        
        setTimeout(() => {
          navigate('/parent-dashboard');
        }, 2000);
      } else {
        toast.error(data || 'Failed to update email. Please try again.');
      }
    } catch (error) {
      console.error('Error updating email:', error);
      toast.error('An error occurred. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
  };

  if (!parentData) {
    return (
      <div className="d-flex justify-content-center align-items-center min-vh-100">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-vh-100 bg-light">
      {/* Sticky Navbar */}
      <nav className="navbar navbar-expand-lg bg-dark navbar-dark fixed-top shadow-sm">
        <div className="container-fluid px-4">
          <span className="navbar-brand d-flex align-items-center">
            <img 
              src="https://img.icons8.com/color/48/000000/protection-mask.png" 
              alt="logo" 
              className="me-2" 
              style={{ width: '32px', height: '32px' }}
            />
            Child Insurance Portal
          </span>
          <div className="d-flex align-items-center">
            <div className="position-relative me-3">
              <FaBell className="text-light" style={{ fontSize: '1.2rem' }} />
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                2
              </span>
            </div>
            <span className="text-light me-3">{parentData.email}</span>
            <button className="btn btn-outline-light d-flex align-items-center" onClick={handleLogout}>
              <FaSignOutAlt className="me-2" />
              Logout
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container-fluid" style={{ marginTop: '76px', height: 'calc(100vh - 76px)', overflow: 'hidden' }}>
        <div className="row h-100">
          {/* Image Section - Left */}
          <div className="col-lg-5 d-none d-lg-flex align-items-center justify-content-center" 
               style={{ 
                 background: 'linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)',
                 height: '100%'
               }}>
            <img
              src="https://img.freepik.com/free-vector/family-health-insurance-abstract-concept-vector-illustration-health-insurance-policy-medical-care-family-members-healthcare-service-medicine-coverage-parent-child-protection-abstract-metaphor_335657-1427.jpg"
              alt="Child Insurance Illustration"
              style={{
                width: '90%',
                height: 'auto',
                maxHeight: '70vh',
                objectFit: 'contain',
                filter: 'drop-shadow(0 10px 15px rgba(0,0,0,0.1))'
              }}
            />
          </div>

          {/* Form Section - Right */}
          <div className="col-lg-7 px-0 h-100 d-flex flex-column">
            {/* Welcome Card - Full Width */}
            <div className="bg-primary text-white w-100 p-4">
              <div className="d-flex align-items-center">
                <div className="bg-white rounded-circle p-3 me-4">
                  <FaUser className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="mb-2">Hello, {parentData.parentName}!</h3>
                  <p className="mb-0 fs-5 opacity-75">Update your email address below</p>
                </div>
              </div>
            </div>

            {/* Form Section - Full Width */}
            <div className="flex-grow-1 bg-white p-4 d-flex flex-column justify-content-center">
              {/* Email Update Form Header */}
              <div className="mb-4">
                <div className="d-flex align-items-center">
                  <FaEnvelope className="text-primary me-2" size={20} />
                  <h4 className="mb-0 fw-bold">Update Email Address</h4>
                </div>
              </div>

              {/* Form Content */}
              <form onSubmit={handleSubmit} className="d-flex flex-column" style={{ gap: '1.5rem' }}>
                <div>
                  <label className="form-label text-muted mb-2">Current Email</label>
                  <div className="input-group shadow-sm rounded-3 overflow-hidden">
                    <div className="input-group-text border-0 ps-3 pe-1 bg-light">
                      <FaEnvelope className="text-muted" />
                    </div>
                    <input
                      type="email"
                      className="form-control border-0 bg-light py-2 px-2"
                      value={parentData.email}
                      disabled
                      style={{ fontSize: '1rem' }}
                    />
                  </div>
                </div>

                <div>
                  <label className="form-label text-muted mb-2">New Email</label>
                  <div className="input-group shadow-sm rounded-3 overflow-hidden">
                    <div className="input-group-text border-0 ps-3 pe-1 bg-white">
                      <FaEnvelope className="text-primary" />
                    </div>
                    <input
                      type="email"
                      className="form-control border-0 py-2 px-2"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      required
                      placeholder="Enter new email address"
                      style={{ fontSize: '1rem' }}
                    />
                  </div>
                </div>

                <div className="d-grid gap-3 mt-auto">
                  <button 
                    type="submit" 
                    className="btn btn-primary py-2 rounded-3 shadow-sm"
                    disabled={isLoading}
                    style={{ fontSize: '1rem' }}
                  >
                    {isLoading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Updating...
                      </>
                    ) : (
                      'Update Email'
                    )}
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-outline-secondary py-2 d-flex align-items-center justify-content-center rounded-3"
                    onClick={() => navigate('/parent-dashboard')}
                    disabled={isLoading}
                    style={{ fontSize: '1rem' }}
                  >
                    <FaArrowLeft className="me-2" />
                    Back to Dashboard
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-right" />
    </div>
  );
};

export default ParentEmailEdit;