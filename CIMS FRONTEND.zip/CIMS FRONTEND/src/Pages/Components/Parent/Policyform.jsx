import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './AllContact.css';
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const PolicyForm = () => {
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]); // Default to today's date
  const [parentEmailId, setParentEmailId] = useState('');
  const [childName, setChildName] = useState('');
  const [childrenList, setChildrenList] = useState([]);
  const [plan, setPlan] = useState('Guardian Shield');
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  // Load parent email and children list from localStorage on component mount
  useEffect(() => {
    const userEmail = localStorage.getItem("userEmail");
    const userDetails = localStorage.getItem("userDetails");

    if (!userEmail || !userDetails) {
      toast.error("Please log in first");
      navigate("/");
      return;
    }

    try {
      const parsedData = JSON.parse(userDetails);
      const dashboard = parsedData.dashboard || parsedData;
      
      // Set parent email
      setParentEmailId(userEmail);
      
      // Set children list
      const children = dashboard.childrenNames || [];
      setChildrenList(children);
      
      // Set first child as default if available
      if (children.length > 0) {
        setChildName(children[0]);
      }
    } catch (error) {
      console.error("Error loading user details:", error);
      toast.error("Error loading user details");
    }
  }, [navigate]);

  // Validate date format (YYYY-MM-DD)
  const isValidDate = (date) => {
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(date);
  };

  // Validation function
  const validateForm = () => {
    const newErrors = {};

    if (!parentEmailId.trim()) {
      newErrors.parentEmailId = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(parentEmailId)) {
      newErrors.parentEmailId = 'Enter a valid email address';
    }

    if (!childName.trim()) {
      newErrors.childName = 'Child name is required';
    }

    if (!plan.trim()) {
      newErrors.plan = 'Plan selection is required';
    }

    if (!isValidDate(startDate)) {
      newErrors.startDate = 'Start Date must be in the format YYYY-MM-DD';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form data
    if (!validateForm()) return;

    setIsLoading(true);

    const data = {
      startDate,
      parent: { parentEmailId },
      child: { childName },
      plan: { name: plan }
    };

    try {
      const response = await axios.post('http://localhost:9094/api/policy/buypolicy', data);
      console.log("Response:", response);

      if (response.status === 200 || response.status === 201) {
        setSuccessMessage("Congratulations! Your policy has been successfully created.");
        toast.success("Policy created successfully!");
        setTimeout(() => {
          navigate('/Buypolicy');
        }, 3000);
      }
    } catch (error) {
      console.error("Error buying policy:", error);
      toast.error("Error in buying policy. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="policy-form-container">
      <h2 className="policy-form-title">Buy Policy</h2>
      <form className="policy-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="startDate">Start Date</label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="form-control"
            required
            min={new Date().toISOString().split('T')[0]}
          />
          {errors.startDate && <div className="error">{errors.startDate}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="parentEmailId">Parent Email</label>
          <input
            type="email"
            id="parentEmailId"
            value={parentEmailId}
            className="form-control"
            required
            readOnly
            style={{ backgroundColor: '#f8f9fa' }}
          />
          {errors.parentEmailId && <div className="error">{errors.parentEmailId}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="childName">Child Name</label>
          {childrenList.length > 0 ? (
            <select
            id="childName"
            value={childName}
            onChange={(e) => setChildName(e.target.value)}
            className="form-control"
            required
            >
              {childrenList.map((child, index) => (
                <option key={index} value={child}>
                  {child}
                </option>
              ))}
            </select>
          ) : (
            <div className="alert alert-warning">
              No children registered. Please add a child first.
            </div>
          )}
          {errors.childName && <div className="error">{errors.childName}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="plan">Plan</label>
          <select
            id="plan"
            value={plan}
            onChange={(e) => setPlan(e.target.value)}
            className="form-control"
            required
          >
            <option value="Guardian Shield">Guardian Shield</option>
            <option value="EduHealth Shield">EduHealth Shield</option>
            <option value="BrightPathEdu Shield">BrightPathEdu Shield</option>
          </select>
          {errors.plan && <div className="error">{errors.plan}</div>}
        </div>

        <div className="form-group">
          <button 
            type="submit" 
            className="submit-btn"
            disabled={isLoading || childrenList.length === 0}
          >
            {isLoading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Processing...
              </>
            ) : (
              'Submit'
            )}
          </button>
        </div>
      </form>

      {successMessage && (
        <div className="success-message mt-3">
          {successMessage}
        </div>
      )}
      
      <ToastContainer position="top-right" />
    </div>
  );
};

export default PolicyForm;
