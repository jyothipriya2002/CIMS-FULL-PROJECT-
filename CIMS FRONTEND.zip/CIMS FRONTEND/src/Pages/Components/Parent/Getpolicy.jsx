import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AllContact.css';

const Getpolicy = () => {
  const [email, setEmail] = useState('');
  const [plans, setPlans] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchPlans = async () => {
    try {
      const response = await axios.get('http://localhost:9094/api/user/plans', {
        params: { email }
      });
      setPlans(response.data);
      setError('');
    } catch (err) {
      console.error(err);
      setPlans([]);
      setError('Failed to fetch plans. Please check the email.');
    }
  };

  const goBack = () => {
    navigate('/parent-dashboard');
  };

  return (
    <div className="get-policy-container">
      <h2>Get Parent's Plans</h2>

      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter parent email"
        className="input-field"
      />

      <button onClick={fetchPlans} className="get-btn">
        Get
      </button>

      <button onClick={goBack} className="back-btn">
        Back
      </button>

      {error && <p className="error-text">{error}</p>}

      {plans.length > 0 && (
        <table className="plans-table">
          <thead>
            <tr>
              <th>Plan Name</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((plan, index) => (
              <tr key={index}>
                <td>{plan}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Getpolicy;
