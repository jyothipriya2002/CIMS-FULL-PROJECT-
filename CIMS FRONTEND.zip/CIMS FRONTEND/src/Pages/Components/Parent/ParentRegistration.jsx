import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "bootstrap/dist/css/bootstrap.min.css";
import { Eye, EyeOff } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePassword = (password) => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return passwordRegex.test(password);
};

const validateName = (name) => {
  // Only capital letters, spaces, and hyphens, minimum 2 characters
  const nameRegex = /^[A-Z\s-]{2,}$/;
  return nameRegex.test(name);
};

const validatePhoneNumber = (number) => {
  // Check for repeated zeros and valid number format
  if (/0{5,}/.test(number)) return false; // Prevents more than 4 zeros in a row
  return /^\d{10}$/.test(number) && number.trim() !== '0000000000';
};

const countryCodes = [
  { code: '+91', country: 'India' },
  { code: '+1', country: 'USA' },
  { code: '+44', country: 'UK' },
  { code: '+61', country: 'Australia' },
  { code: '+86', country: 'China' },
  { code: '+81', country: 'Japan' },
  // Add more country codes as needed
];

const ParentRegistration = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    parentName: "",
    parentGender: "",
    parentEmailId: "",
    parentPw: "",
    confirmPw: "",
    countryCode: "+91", // Default to India
    contactNumber: ""
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);
  const [errors, setErrors] = useState({});

  const isMismatch = formData.parentPw && formData.confirmPw && formData.parentPw !== formData.confirmPw;

  const handleParentChange = (e) => {
    const { name, value } = e.target;
    if (name === 'parentName') {
      // Convert to uppercase for name field
      setFormData((prev) => ({ ...prev, [name]: value.toUpperCase() }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const newErrors = {};

    // Name validation
    if (!formData.parentName) {
      newErrors.parentName = "Name is required";
    } else if (!validateName(formData.parentName)) {
      newErrors.parentName = "Please enter a valid name (CAPITAL LETTERS only)";
    }

    // Gender validation
    if (!formData.parentGender) {
      newErrors.parentGender = "Gender selection is required";
    }

    // Email validation
    if (!formData.parentEmailId) {
      newErrors.parentEmailId = "Email is required";
    } else if (!validateEmail(formData.parentEmailId)) {
      newErrors.parentEmailId = "Please enter a valid email address";
    }

    // Password validation
    if (!formData.parentPw) {
      newErrors.parentPw = "Password is required";
    } else if (!validatePassword(formData.parentPw)) {
      newErrors.parentPw = "Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character";
    }

    // Confirm password validation
    if (!formData.confirmPw) {
      newErrors.confirmPw = "Please confirm your password";
    } else if (formData.parentPw !== formData.confirmPw) {
      newErrors.confirmPw = "Passwords do not match";
    }

    // Contact number validation
    if (!formData.contactNumber) {
      newErrors.contactNumber = "Contact number is required";
    } else if (!validatePhoneNumber(formData.contactNumber)) {
      newErrors.contactNumber = "Please enter a valid phone number (no repeated zeros)";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!validate()) {
      toast.error("Please fill all required fields correctly.");
      return;
    }
  
    try {
      // Combine country code and phone number
      const dataToSubmit = {
        ...formData,
        contactNumber: `${formData.countryCode}${formData.contactNumber}`
      };

      const response = await axios.post("http://localhost:9094/api/user/registration", dataToSubmit);
      
      if (response.status === 200 || response.status === 201) {
        toast.success("Registration successful!");
        setTimeout(() => navigate("/"), 2000);
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      toast.error(error.response?.data?.message || "Something went wrong!");
    }
  };

  return (
    <div className="vh-100 d-flex" style={{ overflow: 'hidden' }}>
      <div 
        className="d-none d-lg-flex flex-column justify-content-center align-items-center text-white p-4" 
        style={{ 
          width: "40%",
          background: `linear-gradient(to bottom, 
            rgba(20, 17, 38, 0.95), 
            rgba(28, 20, 56, 0.92)
          ), url('https://images.unsplash.com/photo-1475274047050-1d0c0975c63e?q=80&w=1920&h=1080&fit=crop')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          boxShadow: "inset 0 0 150px rgba(0,0,0,0.5)",
          position: "relative",
          overflow: "hidden"
        }}
      >
        <div className="position-absolute top-0 left-0 w-100 h-100" 
             style={{
               background: "url('data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='50' cy='50' r='1' fill='rgba(255,255,255,0.3)'/%3E%3C/svg%3E')",
               opacity: "0.3"
             }}>
        </div>
        <div className="text-center mb-4 position-relative">
          <h2 className="display-4 fw-bold mb-3" style={{ 
            textShadow: "2px 2px 4px rgba(0,0,0,0.5)",
            color: "rgba(255,255,255,0.95)" 
          }}>
            Welcome to Child Insurance
          </h2>
          <p className="lead mb-4" style={{ 
            fontSize: "1.2rem", 
            opacity: 0.9, 
            textShadow: "1px 1px 2px rgba(0,0,0,0.3)",
            color: "rgba(255,255,255,0.8)"
          }}>
            Secure your child's future with our comprehensive insurance plans
          </p>
        </div>
        <div className="text-center position-relative" style={{ 
          filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.3))"
        }}>
          <img 
            src="https://img.freepik.com/free-vector/happy-family-with-child-jumping-having-fun-together_74855-5242.jpg" 
            alt="Family Illustration" 
            className="img-fluid rounded-4"
            style={{ maxWidth: "80%" }}
          />
        </div>
      </div>

      <div className="flex-grow-1 d-flex justify-content-center align-items-center p-3 p-md-4"
           style={{ 
             background: "linear-gradient(rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.98))",
             backdropFilter: "blur(10px)",
             overflow: 'auto',
             maxHeight: '100vh'
           }}>
        <div className="card shadow-lg" style={{ maxWidth: "500px", width: "100%" }}>
          <div className="card-body p-4">
            <h2 className="text-center text-primary mb-4">Registration Form</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <input
                  name="parentName"
                  value={formData.parentName}
                  onChange={handleParentChange}
                  placeholder="Parent Name (CAPITAL LETTERS)"
                  className={`form-control rounded-pill ${errors.parentName && "is-invalid"}`}
                  style={{ textTransform: 'uppercase' }}
                />
                {errors.parentName && <div className="invalid-feedback">{errors.parentName}</div>}
              </div>

              <div className="mb-3">
                <select
                  name="parentGender"
                  value={formData.parentGender}
                  onChange={handleParentChange}
                  className={`form-control rounded-pill ${errors.parentGender && "is-invalid"}`}
                >
                  <option value="">Select Gender</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
                {errors.parentGender && <div className="invalid-feedback">{errors.parentGender}</div>}
              </div>

              <div className="mb-3">
                <input
                  name="parentEmailId"
                  type="email"
                  value={formData.parentEmailId}
                  onChange={handleParentChange}
                  placeholder="Email"
                  className={`form-control rounded-pill ${errors.parentEmailId && "is-invalid"}`}
                />
                {errors.parentEmailId && <div className="invalid-feedback">{errors.parentEmailId}</div>}
              </div>

              <div className="mb-3 position-relative">
                <input
                  name="parentPw"
                  type={showPassword ? "text" : "password"}
                  value={formData.parentPw}
                  onChange={handleParentChange}
                  placeholder="Password"
                  className={`form-control rounded-pill ${errors.parentPw ? "is-invalid" : ""}`}
                />
                <span
                  className="position-absolute top-50 end-0 translate-middle-y pe-3"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ cursor: "pointer" }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
                {errors.parentPw && <div className="invalid-feedback">{errors.parentPw}</div>}
              </div>

              <div className="mb-3 position-relative">
                <input
                  name="confirmPw"
                  type={showConfirmPw ? "text" : "password"}
                  value={formData.confirmPw}
                  onChange={handleParentChange}
                  placeholder="Confirm Password"
                  className={`form-control rounded-pill ${errors.confirmPw ? "is-invalid" : ""}`}
                />
                <span
                  className="position-absolute top-50 end-0 translate-middle-y pe-3"
                  onClick={() => setShowConfirmPw(!showConfirmPw)}
                  style={{ cursor: "pointer" }}
                >
                  {showConfirmPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
                {errors.confirmPw && <div className="invalid-feedback">{errors.confirmPw}</div>}
              </div>

              <div className="mb-3">
                <div className="input-group">
                  <select
                    name="countryCode"
                    value={formData.countryCode}
                    onChange={handleParentChange}
                    className="form-select rounded-start"
                    style={{ maxWidth: "150px" }}
                  >
                    {countryCodes.map((country) => (
                      <option key={country.code} value={country.code}>
                        {country.code} ({country.country})
                      </option>
                    ))}
                  </select>
                  <input
                    name="contactNumber"
                    value={formData.contactNumber}
                    onChange={handleParentChange}
                    placeholder="Contact Number"
                    className={`form-control ${errors.contactNumber && "is-invalid"}`}
                    maxLength="10"
                  />
                  {errors.contactNumber && <div className="invalid-feedback">{errors.contactNumber}</div>}
                </div>
              </div>

              <button type="submit" className="btn btn-success rounded-pill w-100">
                Register
              </button>
            </form>
            <p className="text-center mt-3">
              Already registered? <Link to="/login" className="text-primary text-decoration-none">Login here</Link>
            </p>
          </div>
        </div>
        <ToastContainer position="top-right" autoClose={3000} />
      </div>
    </div>
  );
};

export default ParentRegistration;