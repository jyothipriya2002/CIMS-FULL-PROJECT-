import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate, Link } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import "bootstrap/dist/css/bootstrap.min.css";
import API_ENDPOINTS, { fetchOptions } from "../../config/api";

const AuthenticationPage = () => {
  const navigate = useNavigate();
  const [userType, setUserType] = useState("parent");
  const [isLoading, setIsLoading] = useState(false);
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const handleUserTypeChange = (e) => {
    setUserType(e.target.value);
    setLoginData({ email: "", password: "" });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      console.log("Attempting login with:", {
        type: userType,
        email: loginData.email
      });

      if (userType === "parent") {
        const response = await fetch(API_ENDPOINTS.LOGIN, {
          ...fetchOptions,
          method: "POST",
          body: JSON.stringify({
            parentEmailId: loginData.email,
            parentPw: loginData.password
          }),
        });

        console.log("Login response status:", response.status);
        
        const data = await response.json();
        console.log("Response data:", data);

        // Check for valid parent data
        const dashboard = data.dashboard || data;
        if (response.ok && dashboard.parentName) {
          console.log("Login successful, data:", data);
          localStorage.setItem("userEmail", loginData.email);
          localStorage.setItem("userDetails", JSON.stringify(data));
          toast.success("Login successful!");
          navigate("/parent-dashboard");
        } else {
          // Show error if not a registered parent
          throw new Error("You are not registered. Please register first before logging in.");
        }
      } else {
        // Admin login
        const response = await fetch(API_ENDPOINTS.ADMIN_LOGIN, {
          ...fetchOptions,
          method: "POST",
          body: JSON.stringify({
            adminEmail: loginData.email,
            adminPassword: loginData.password
          }),
        });

        const text = await response.text();
        
        if (text.includes("Login Successfull") || text.includes("Login Successful")) {
          // Store admin token and data
          localStorage.setItem("adminToken", "true");
          localStorage.setItem("adminData", JSON.stringify({
            adminEmail: loginData.email,
            adminName: "Admin",
            totalParents: 0,
            totalPolicies: 0,
            pendingClaims: 0
          }));
          
          toast.success("Admin login successful!");
          navigate("/admin-dashboard");
        } else {
          try {
            const errorData = JSON.parse(text);
            throw new Error(errorData.message || "Invalid admin credentials");
          } catch {
            throw new Error("Invalid credentials");
          }
        }
      }
    } catch (error) {
      console.error("Login error:", error);
      toast.error(error.message || "Connection error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ 
      minHeight: "100vh",
      width: "100vw",
      height: "100vh",
      position: "fixed",
      top: 0,
      left: 0,
      background: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://img.freepik.com/free-photo/happy-family-with-their-little-daughter_329181-9334.jpg')`,
      backgroundSize: "100% 100%",
      backgroundPosition: "center",
      backgroundRepeat: "no-repeat",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "auto"
    }}>
      <div className="container" style={{ maxWidth: "1200px", margin: "2rem auto" }}>
        <div className="row">
          <div className="col-md-6">
            <h1 style={{ 
              color: "white", 
              fontSize: "3.2rem",
              marginBottom: "1.5rem"
            }}>Child Insurance Portal</h1>
            <p style={{ 
              color: "white",
              fontSize: "1.4rem",
              opacity: 0.9,
              maxWidth: "600px",
              lineHeight: 1.6
            }}>
              Secure your child's future with our comprehensive insurance coverage. 
              We provide flexible plans tailored to your needs.
            </p>
          </div>
          <div className="col-md-6 d-flex justify-content-end">
            <div style={{ 
              backgroundColor: "rgba(255, 255, 255, 0.95)",
              padding: "2rem",
              borderRadius: "12px",
              width: "400px",
              backdropFilter: "blur(10px)"
            }}>
              <h2 className="text-center mb-4">Sign In</h2>
              <form onSubmit={handleLogin}>
                <div className="mb-3">
                  <select
                    className="form-select mb-3"
                    value={userType}
                    onChange={handleUserTypeChange}
                    disabled={isLoading}
                    style={{
                      padding: "0.8rem",
                      borderRadius: "8px"
                    }}
                  >
                    <option value="parent">Parent Account</option>
                    <option value="admin">Administrator</option>
                  </select>

                  <input
                    type="email"
                    name="email"
                    className="form-control mb-3"
                    placeholder="Email"
                    value={loginData.email}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                    style={{
                      padding: "0.8rem",
                      borderRadius: "8px"
                    }}
                  />

                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    placeholder="Password"
                    value={loginData.password}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                    style={{
                      padding: "0.8rem",
                      borderRadius: "8px"
                    }}
                  />
                </div>

                <button 
                  type="submit" 
                  className="btn btn-primary w-100"
                  disabled={isLoading}
                  style={{
                    padding: "0.8rem",
                    borderRadius: "8px",
                    fontSize: "1rem",
                    marginTop: "1rem"
                  }}
                >
                  {isLoading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Signing in...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </button>

                {userType === "parent" && (
                  <p className="text-center mt-3 mb-0">
                    Don't have an account? {" "}
                    <Link to="/register" style={{ textDecoration: "none" }}>
                      Sign up here
                    </Link>
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-right" />
    </div>
  );
};

export default AuthenticationPage; 