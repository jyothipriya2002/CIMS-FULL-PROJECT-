import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Claim.css';

const Claim = () => {
  const [parentId, setParentId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [reason, setReason] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!parentId || !policyId || !reason) {
      setError('All fields are required.');
      setMessage('');
      console.warn('Form submission blocked: Fields missing');
      return;
    }

    const claimData = {
      reason,
      parent: { parent_Id: parseInt(parentId) },
      policy: { id: parseInt(policyId) }
    };

    console.log('Submitting claim with data:', claimData);

    try {
      const response = await axios.post(
        'http://localhost:9094/api/claims/submit',
        claimData
      );

      console.log('Backend response:', response.data);
      setMessage(response.data); // assuming backend returns a string
      setError('');

      // Optional: Redirect after success
      setTimeout(() => {
        navigate('/parent-dashboard');
      }, 2000);

    } catch (err) {
      console.error('Error submitting claim:', err);
      setError(err.response?.data || 'Error submitting claim.');
      setMessage('');
    }
  };

  return (
    <div className='claim-div'>

    
    <div className='clm'>
      <div className="claim-container">
        <h2>Claim </h2>
        <form className="claim-form" onSubmit={handleSubmit}>
          <label>Parent ID:</label>
          <input
            type="number"
            value={parentId}
            onChange={(e) => setParentId(e.target.value)}
            required
          />

          <label>Policy ID:</label>
          <input
            type="number"
            value={policyId}
            onChange={(e) => setPolicyId(e.target.value)}
            required
          />

          <label>Reason:</label>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            required
            rows="4"
          />

          <button type="submit">Submit Claim</button>
        </form>

        {message && <p className="success-msg">{message}</p>}
        {error && <p className="error-msg">{error}</p>}
      </div>
    </div>
    </div>
  );
};

export default Claim;
