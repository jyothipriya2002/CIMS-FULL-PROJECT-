// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react-swc'

// // https://vite.dev/config/
// export default defineConfig({
//   plugins: [react()],
//   server: {
//     proxy: {
//       '/api': {
//         target: 'http://localhost:9094', // your backend port
//         changeOrigin: true,
//         secure: false,
//       },
//     },
//   },
// })

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    open: true,
    cors: true,
    proxy: {
      '/api': {
        target: 'http://localhost:9094',
        changeOrigin: true,
        secure: false,
        ws: true,           // proxy websockets as well
        // no need to rewrite since /api → /api is identity
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: true,      // optional, but useful in prod-debug
  },
});
